
### Loading the libraries


```python
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

```


```python
data=pd.read_csv("TrainingData - Training.csv")
```


```python
data.dtypes
```




    Period                                 object
    EQ                                    float64
    Social_Search_Impressions             float64
    Social_Search_Working_cost            float64
    Digital_Impressions                   float64
    Digital_Working_cost                  float64
    Print_Impressions.Ads40               float64
    Print_Working_Cost.Ads50              float64
    OOH_Impressions                       float64
    OOH_Working_Cost                      float64
    SOS_pct                               float64
    Digital_Impressions_pct               float64
    CCFOT                                 float64
    Median_Temp                           float64
    Median_Rainfall                       float64
    Fuel_Price                            float64
    Inflation                             float64
    Trade_Invest                          float64
    Brand_Equity                          float64
    Avg_EQ_Price                          float64
    Any_Promo_pct_ACV                     float64
    Any_Feat_pct_ACV                      float64
    Any_Disp_pct_ACV                      float64
    EQ_Base_Price                         float64
    Est_ACV_Selling                         int64
    pct_ACV                               float64
    Avg_no_of_Items                       float64
    pct_PromoMarketDollars_Category       float64
    RPI_Category                          float64
    Magazine_Impressions_pct              float64
    TV_GRP                                float64
    Competitor1_RPI                       float64
    Competitor2_RPI                       float64
    Competitor3_RPI                       float64
    Competitor4_RPI                       float64
    EQ_Category                           float64
    EQ_Subcategory                        float64
    pct_PromoMarketDollars_Subcategory    float64
    RPI_Subcategory                       float64
    dtype: object




```python
data.describe(include="all").T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>unique</th>
      <th>top</th>
      <th>freq</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Period</th>
      <td>34</td>
      <td>34</td>
      <td>2016 - Period:8</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>EQ</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>323.714</td>
      <td>121.512</td>
      <td>130.937</td>
      <td>238.093</td>
      <td>292.629</td>
      <td>445.079</td>
      <td>546.053</td>
    </tr>
    <tr>
      <th>Social_Search_Impressions</th>
      <td>24</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.22942e+07</td>
      <td>1.02196e+07</td>
      <td>21600</td>
      <td>3.79002e+06</td>
      <td>9.85739e+06</td>
      <td>1.69532e+07</td>
      <td>4.03974e+07</td>
    </tr>
    <tr>
      <th>Social_Search_Working_cost</th>
      <td>24</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>51957.2</td>
      <td>42730</td>
      <td>2006.67</td>
      <td>20550.5</td>
      <td>35200.7</td>
      <td>81174.7</td>
      <td>153277</td>
    </tr>
    <tr>
      <th>Digital_Impressions</th>
      <td>23</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.83392e+06</td>
      <td>4.19566e+06</td>
      <td>29892.2</td>
      <td>402766</td>
      <td>3.00659e+06</td>
      <td>5.94667e+06</td>
      <td>1.83005e+07</td>
    </tr>
    <tr>
      <th>Digital_Working_cost</th>
      <td>23</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>42576.9</td>
      <td>47739.2</td>
      <td>1800.34</td>
      <td>5787.39</td>
      <td>23206</td>
      <td>68823</td>
      <td>170508</td>
    </tr>
    <tr>
      <th>Print_Impressions.Ads40</th>
      <td>33</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.00868e+06</td>
      <td>3.64076e+06</td>
      <td>1.4e-05</td>
      <td>1.66649e-05</td>
      <td>2374.54</td>
      <td>1.4493e+06</td>
      <td>1.20585e+07</td>
    </tr>
    <tr>
      <th>Print_Working_Cost.Ads50</th>
      <td>33</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>32298.9</td>
      <td>55891.8</td>
      <td>1.5e-05</td>
      <td>1.99805e-05</td>
      <td>404.647</td>
      <td>48695.4</td>
      <td>207179</td>
    </tr>
    <tr>
      <th>OOH_Impressions</th>
      <td>10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.93068e+08</td>
      <td>1.29092e+09</td>
      <td>28807.2</td>
      <td>2.21397e+07</td>
      <td>5.31317e+07</td>
      <td>2.01269e+09</td>
      <td>3.11966e+09</td>
    </tr>
    <tr>
      <th>OOH_Working_Cost</th>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.20235e+06</td>
      <td>3.29983e+06</td>
      <td>350.551</td>
      <td>191936</td>
      <td>3.1137e+06</td>
      <td>5.15062e+06</td>
      <td>8.61731e+06</td>
    </tr>
    <tr>
      <th>SOS_pct</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11.9269</td>
      <td>11.5476</td>
      <td>0.102858</td>
      <td>1.62626</td>
      <td>10.4045</td>
      <td>18.2196</td>
      <td>47.4422</td>
    </tr>
    <tr>
      <th>Digital_Impressions_pct</th>
      <td>10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>14.5566</td>
      <td>28.2636</td>
      <td>0.00385256</td>
      <td>0.576111</td>
      <td>2.5354</td>
      <td>7.9504</td>
      <td>88.1827</td>
    </tr>
    <tr>
      <th>CCFOT</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>87.1874</td>
      <td>19.6534</td>
      <td>20</td>
      <td>79.2411</td>
      <td>100</td>
      <td>100</td>
      <td>100</td>
    </tr>
    <tr>
      <th>Median_Temp</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>56.525</td>
      <td>15.3659</td>
      <td>32.95</td>
      <td>43.675</td>
      <td>57.3</td>
      <td>71.0875</td>
      <td>77.35</td>
    </tr>
    <tr>
      <th>Median_Rainfall</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.392647</td>
      <td>0.169939</td>
      <td>0.095</td>
      <td>0.27375</td>
      <td>0.3925</td>
      <td>0.5375</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>Fuel_Price</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10.0938</td>
      <td>1.15855</td>
      <td>7.473</td>
      <td>9.35875</td>
      <td>9.9015</td>
      <td>10.9187</td>
      <td>12.286</td>
    </tr>
    <tr>
      <th>Inflation</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0175021</td>
      <td>0.00565918</td>
      <td>0.00783248</td>
      <td>0.0134349</td>
      <td>0.0186385</td>
      <td>0.0215551</td>
      <td>0.0268836</td>
    </tr>
    <tr>
      <th>Trade_Invest</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>15558.1</td>
      <td>19845.8</td>
      <td>365.43</td>
      <td>837.805</td>
      <td>1625.31</td>
      <td>34109.9</td>
      <td>61675.3</td>
    </tr>
    <tr>
      <th>Brand_Equity</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>43.3773</td>
      <td>0.747459</td>
      <td>42.14</td>
      <td>42.7361</td>
      <td>43.5682</td>
      <td>44</td>
      <td>44.45</td>
    </tr>
    <tr>
      <th>Avg_EQ_Price</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52.072</td>
      <td>3.84225</td>
      <td>44.7826</td>
      <td>49.4825</td>
      <td>51.2195</td>
      <td>54.0033</td>
      <td>60.6779</td>
    </tr>
    <tr>
      <th>Any_Promo_pct_ACV</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7.12176</td>
      <td>3.80081</td>
      <td>0.328645</td>
      <td>5.39755</td>
      <td>7.73618</td>
      <td>8.76227</td>
      <td>16.5384</td>
    </tr>
    <tr>
      <th>Any_Feat_pct_ACV</th>
      <td>11</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.1902</td>
      <td>1.20001</td>
      <td>1.63399</td>
      <td>5.33789</td>
      <td>5.55957</td>
      <td>5.68117</td>
      <td>5.84497</td>
    </tr>
    <tr>
      <th>Any_Disp_pct_ACV</th>
      <td>22</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.66636</td>
      <td>1.95805</td>
      <td>0.0332756</td>
      <td>0.226414</td>
      <td>1.0087</td>
      <td>1.82618</td>
      <td>7.92542</td>
    </tr>
    <tr>
      <th>EQ_Base_Price</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.52767</td>
      <td>0.0919972</td>
      <td>1.42341</td>
      <td>1.45127</td>
      <td>1.49098</td>
      <td>1.59408</td>
      <td>1.70252</td>
    </tr>
    <tr>
      <th>Est_ACV_Selling</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6.00453e+09</td>
      <td>2.09568e+09</td>
      <td>2.90461e+09</td>
      <td>4.46905e+09</td>
      <td>5.61517e+09</td>
      <td>7.88761e+09</td>
      <td>8.7069e+09</td>
    </tr>
    <tr>
      <th>pct_ACV</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>26.0453</td>
      <td>9.49002</td>
      <td>13.0361</td>
      <td>15.9317</td>
      <td>24.7048</td>
      <td>34.9268</td>
      <td>39.441</td>
    </tr>
    <tr>
      <th>Avg_no_of_Items</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.44038</td>
      <td>0.107286</td>
      <td>2.07566</td>
      <td>2.37745</td>
      <td>2.43732</td>
      <td>2.49704</td>
      <td>2.66442</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Category</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0228625</td>
      <td>0.0185172</td>
      <td>0.000238</td>
      <td>0.00612</td>
      <td>0.02235</td>
      <td>0.0331</td>
      <td>0.0701</td>
    </tr>
    <tr>
      <th>RPI_Category</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.4454</td>
      <td>2.61614</td>
      <td>32.4837</td>
      <td>36.7193</td>
      <td>38.4857</td>
      <td>39.6394</td>
      <td>43.8292</td>
    </tr>
    <tr>
      <th>Magazine_Impressions_pct</th>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>46.0594</td>
      <td>23.4533</td>
      <td>7.08095</td>
      <td>32.0723</td>
      <td>40.6527</td>
      <td>54.697</td>
      <td>100</td>
    </tr>
    <tr>
      <th>TV_GRP</th>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>32.0083</td>
      <td>17.1006</td>
      <td>2.2</td>
      <td>23.1</td>
      <td>35.1</td>
      <td>44.7</td>
      <td>54.6</td>
    </tr>
    <tr>
      <th>Competitor1_RPI</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>102.146</td>
      <td>8.80668</td>
      <td>83.8835</td>
      <td>97.0514</td>
      <td>100.76</td>
      <td>105.313</td>
      <td>121.89</td>
    </tr>
    <tr>
      <th>Competitor2_RPI</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.876</td>
      <td>5.1965</td>
      <td>32.369</td>
      <td>35.7359</td>
      <td>37.346</td>
      <td>40.6091</td>
      <td>57.7978</td>
    </tr>
    <tr>
      <th>Competitor3_RPI</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>44.4412</td>
      <td>2.97898</td>
      <td>38.5508</td>
      <td>41.8525</td>
      <td>44.6069</td>
      <td>45.6902</td>
      <td>50.7537</td>
    </tr>
    <tr>
      <th>Competitor4_RPI</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>65.2816</td>
      <td>4.5416</td>
      <td>57.5835</td>
      <td>62.2798</td>
      <td>64.9019</td>
      <td>67.7346</td>
      <td>75.5558</td>
    </tr>
    <tr>
      <th>EQ_Category</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.11679e+06</td>
      <td>392390</td>
      <td>1.50434e+06</td>
      <td>1.86258e+06</td>
      <td>2.01386e+06</td>
      <td>2.39536e+06</td>
      <td>2.86731e+06</td>
    </tr>
    <tr>
      <th>EQ_Subcategory</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>491206</td>
      <td>190922</td>
      <td>249237</td>
      <td>341257</td>
      <td>423234</td>
      <td>624276</td>
      <td>856243</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Subcategory</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.101033</td>
      <td>0.0985979</td>
      <td>0.00165888</td>
      <td>0.0313066</td>
      <td>0.0788523</td>
      <td>0.135781</td>
      <td>0.430051</td>
    </tr>
    <tr>
      <th>RPI_Subcategory</th>
      <td>34</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>42.3352</td>
      <td>2.92113</td>
      <td>35.4807</td>
      <td>40.4485</td>
      <td>42.9413</td>
      <td>44.0382</td>
      <td>47.523</td>
    </tr>
  </tbody>
</table>
</div>




```python
#data.drop(['Period'],axis=1,inplace=True)
```


```python
data.shape
```




    (34, 39)




```python
na_columns=[col for col in data.columns if data[col].isnull().any()]
na_columns
```




    ['Social_Search_Impressions',
     'Social_Search_Working_cost',
     'Digital_Impressions',
     'Digital_Working_cost',
     'Print_Impressions.Ads40',
     'Print_Working_Cost.Ads50',
     'OOH_Impressions',
     'OOH_Working_Cost',
     'Digital_Impressions_pct',
     'Any_Feat_pct_ACV',
     'Any_Disp_pct_ACV',
     'Magazine_Impressions_pct',
     'TV_GRP']




```python
data.isna().sum()
```




    Period                                 0
    EQ                                     0
    Social_Search_Impressions             10
    Social_Search_Working_cost            10
    Digital_Impressions                   11
    Digital_Working_cost                  11
    Print_Impressions.Ads40                1
    Print_Working_Cost.Ads50               1
    OOH_Impressions                       24
    OOH_Working_Cost                      27
    SOS_pct                                0
    Digital_Impressions_pct               24
    CCFOT                                  0
    Median_Temp                            0
    Median_Rainfall                        0
    Fuel_Price                             0
    Inflation                              0
    Trade_Invest                           0
    Brand_Equity                           0
    Avg_EQ_Price                           0
    Any_Promo_pct_ACV                      0
    Any_Feat_pct_ACV                      23
    Any_Disp_pct_ACV                      12
    EQ_Base_Price                          0
    Est_ACV_Selling                        0
    pct_ACV                                0
    Avg_no_of_Items                        0
    pct_PromoMarketDollars_Category        0
    RPI_Category                           0
    Magazine_Impressions_pct              22
    TV_GRP                                22
    Competitor1_RPI                        0
    Competitor2_RPI                        0
    Competitor3_RPI                        0
    Competitor4_RPI                        0
    EQ_Category                            0
    EQ_Subcategory                         0
    pct_PromoMarketDollars_Subcategory     0
    RPI_Subcategory                        0
    dtype: int64



### Replace missing values by mean and drop columns where nearly or more than 30 percent values are missing


```python
mean_PIA_40=data['Print_Impressions.Ads40'].mean()
mean_PWCA_50=data['Print_Working_Cost.Ads50'].mean()
```


```python
data['Print_Impressions.Ads40']=data['Print_Impressions.Ads40'].replace(np.nan,mean_PIA_40)
data['Print_Working_Cost.Ads50']=data['Print_Working_Cost.Ads50'].replace(np.nan,mean_PWCA_50)
```


```python
[col for col in data.columns if data[col].isnull().any()]
```




    ['Social_Search_Impressions',
     'Social_Search_Working_cost',
     'Digital_Impressions',
     'Digital_Working_cost',
     'OOH_Impressions',
     'OOH_Working_Cost',
     'Digital_Impressions_pct',
     'Any_Feat_pct_ACV',
     'Any_Disp_pct_ACV',
     'Magazine_Impressions_pct',
     'TV_GRP']




```python
data_new=data.dropna(axis='columns')
```


```python
data_new
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Period</th>
      <th>EQ</th>
      <th>Print_Impressions.Ads40</th>
      <th>Print_Working_Cost.Ads50</th>
      <th>SOS_pct</th>
      <th>CCFOT</th>
      <th>Median_Temp</th>
      <th>Median_Rainfall</th>
      <th>Fuel_Price</th>
      <th>Inflation</th>
      <th>...</th>
      <th>pct_PromoMarketDollars_Category</th>
      <th>RPI_Category</th>
      <th>Competitor1_RPI</th>
      <th>Competitor2_RPI</th>
      <th>Competitor3_RPI</th>
      <th>Competitor4_RPI</th>
      <th>EQ_Category</th>
      <th>EQ_Subcategory</th>
      <th>pct_PromoMarketDollars_Subcategory</th>
      <th>RPI_Subcategory</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016 - Period:1</td>
      <td>504.784933</td>
      <td>2.008683e+06</td>
      <td>32298.947990</td>
      <td>7.446883</td>
      <td>100.000000</td>
      <td>32.950</td>
      <td>0.5150</td>
      <td>8.226</td>
      <td>0.013258</td>
      <td>...</td>
      <td>0.033900</td>
      <td>35.817030</td>
      <td>97.173365</td>
      <td>35.557371</td>
      <td>44.502717</td>
      <td>63.377268</td>
      <td>1728388.673</td>
      <td>331927.5394</td>
      <td>0.162732</td>
      <td>40.560563</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2016 - Period:2</td>
      <td>490.226477</td>
      <td>1.400000e-05</td>
      <td>0.000015</td>
      <td>11.677082</td>
      <td>87.500000</td>
      <td>34.625</td>
      <td>0.2700</td>
      <td>7.473</td>
      <td>0.009938</td>
      <td>...</td>
      <td>0.039100</td>
      <td>36.389065</td>
      <td>97.850760</td>
      <td>37.223072</td>
      <td>45.720077</td>
      <td>62.731742</td>
      <td>1900859.879</td>
      <td>334611.3806</td>
      <td>0.231650</td>
      <td>40.046301</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016 - Period:3</td>
      <td>479.244686</td>
      <td>1.560000e-05</td>
      <td>0.000017</td>
      <td>0.102858</td>
      <td>96.000000</td>
      <td>46.700</td>
      <td>0.3900</td>
      <td>8.001</td>
      <td>0.007832</td>
      <td>...</td>
      <td>0.022800</td>
      <td>36.599984</td>
      <td>96.397739</td>
      <td>40.800563</td>
      <td>41.822953</td>
      <td>62.090417</td>
      <td>2036436.906</td>
      <td>387148.3582</td>
      <td>0.125394</td>
      <td>40.411115</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016 - Period:4</td>
      <td>489.057428</td>
      <td>1.624000e-05</td>
      <td>0.000019</td>
      <td>0.249055</td>
      <td>100.000000</td>
      <td>49.650</td>
      <td>0.3500</td>
      <td>8.767</td>
      <td>0.010034</td>
      <td>...</td>
      <td>0.014700</td>
      <td>38.201852</td>
      <td>98.936519</td>
      <td>36.576140</td>
      <td>41.578429</td>
      <td>63.374358</td>
      <td>2113635.013</td>
      <td>482489.6740</td>
      <td>0.056603</td>
      <td>42.213246</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016 - Period:5</td>
      <td>477.031994</td>
      <td>1.649600e-05</td>
      <td>0.000019</td>
      <td>13.338804</td>
      <td>100.000000</td>
      <td>58.100</td>
      <td>0.5025</td>
      <td>9.277</td>
      <td>0.009546</td>
      <td>...</td>
      <td>0.021900</td>
      <td>38.648805</td>
      <td>100.509969</td>
      <td>36.032016</td>
      <td>42.602412</td>
      <td>63.291934</td>
      <td>2402211.102</td>
      <td>629826.6484</td>
      <td>0.065059</td>
      <td>43.345578</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2016 - Period:6</td>
      <td>487.855299</td>
      <td>1.659840e-05</td>
      <td>0.000020</td>
      <td>13.562212</td>
      <td>78.571429</td>
      <td>68.500</td>
      <td>0.4600</td>
      <td>9.824</td>
      <td>0.009290</td>
      <td>...</td>
      <td>0.010700</td>
      <td>39.305958</td>
      <td>99.796505</td>
      <td>36.996437</td>
      <td>44.943022</td>
      <td>68.415943</td>
      <td>2796949.720</td>
      <td>806075.7642</td>
      <td>0.029912</td>
      <td>44.075674</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2016 - Period:7</td>
      <td>466.399281</td>
      <td>1.663936e-05</td>
      <td>0.000020</td>
      <td>14.392305</td>
      <td>88.000000</td>
      <td>73.700</td>
      <td>0.4250</td>
      <td>9.642</td>
      <td>0.008284</td>
      <td>...</td>
      <td>0.007650</td>
      <td>39.653897</td>
      <td>101.096185</td>
      <td>37.314308</td>
      <td>43.358409</td>
      <td>65.420869</td>
      <td>2867306.933</td>
      <td>828776.1488</td>
      <td>0.021788</td>
      <td>45.072822</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2016 - Period:8</td>
      <td>546.053084</td>
      <td>1.665574e-05</td>
      <td>0.000020</td>
      <td>15.376127</td>
      <td>84.615385</td>
      <td>77.350</td>
      <td>0.5550</td>
      <td>9.148</td>
      <td>0.008461</td>
      <td>...</td>
      <td>0.030200</td>
      <td>38.322539</td>
      <td>94.654006</td>
      <td>34.013304</td>
      <td>41.356740</td>
      <td>64.478960</td>
      <td>2813494.081</td>
      <td>789109.5698</td>
      <td>0.093287</td>
      <td>42.974524</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2016 - Period:9</td>
      <td>464.925607</td>
      <td>1.666230e-05</td>
      <td>0.000020</td>
      <td>22.932534</td>
      <td>100.000000</td>
      <td>75.850</td>
      <td>0.5600</td>
      <td>9.225</td>
      <td>0.011022</td>
      <td>...</td>
      <td>0.030400</td>
      <td>38.110967</td>
      <td>96.238963</td>
      <td>37.377758</td>
      <td>40.577016</td>
      <td>63.264193</td>
      <td>2441916.655</td>
      <td>606656.5082</td>
      <td>0.100700</td>
      <td>42.760786</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2016 - Period:10</td>
      <td>357.648693</td>
      <td>1.666492e-05</td>
      <td>0.000020</td>
      <td>28.529493</td>
      <td>100.000000</td>
      <td>71.050</td>
      <td>0.2950</td>
      <td>9.331</td>
      <td>0.013966</td>
      <td>...</td>
      <td>0.005610</td>
      <td>39.595750</td>
      <td>105.031551</td>
      <td>46.598751</td>
      <td>44.631443</td>
      <td>67.040049</td>
      <td>2017353.844</td>
      <td>421134.3688</td>
      <td>0.025271</td>
      <td>43.925962</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2016 - Period:11</td>
      <td>298.553287</td>
      <td>1.666597e-05</td>
      <td>0.000020</td>
      <td>8.233143</td>
      <td>100.000000</td>
      <td>60.075</td>
      <td>0.1600</td>
      <td>9.442</td>
      <td>0.014984</td>
      <td>...</td>
      <td>0.002080</td>
      <td>41.020941</td>
      <td>111.436659</td>
      <td>35.327818</td>
      <td>46.055118</td>
      <td>69.657891</td>
      <td>1930470.417</td>
      <td>349816.2482</td>
      <td>0.011440</td>
      <td>44.542796</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2016 - Period:12</td>
      <td>283.797430</td>
      <td>1.666639e-05</td>
      <td>0.000020</td>
      <td>2.299508</td>
      <td>100.000000</td>
      <td>49.350</td>
      <td>0.0950</td>
      <td>9.180</td>
      <td>0.016087</td>
      <td>...</td>
      <td>0.005080</td>
      <td>39.744710</td>
      <td>107.501689</td>
      <td>39.414652</td>
      <td>44.657429</td>
      <td>67.535031</td>
      <td>1756735.667</td>
      <td>297210.5135</td>
      <td>0.035489</td>
      <td>43.417711</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2016 - Period:13</td>
      <td>239.231622</td>
      <td>1.666655e-05</td>
      <td>0.000020</td>
      <td>4.305099</td>
      <td>100.000000</td>
      <td>35.500</td>
      <td>0.3800</td>
      <td>9.462</td>
      <td>0.018697</td>
      <td>...</td>
      <td>0.004600</td>
      <td>39.031286</td>
      <td>105.407369</td>
      <td>40.773680</td>
      <td>44.582400</td>
      <td>65.324834</td>
      <td>1628453.070</td>
      <td>269453.0058</td>
      <td>0.035659</td>
      <td>42.776921</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2017 - Period:2</td>
      <td>355.652264</td>
      <td>1.666665e-05</td>
      <td>0.000020</td>
      <td>1.401843</td>
      <td>100.000000</td>
      <td>40.950</td>
      <td>0.2475</td>
      <td>9.645</td>
      <td>0.026884</td>
      <td>...</td>
      <td>0.049800</td>
      <td>37.393119</td>
      <td>102.149760</td>
      <td>35.954650</td>
      <td>42.736638</td>
      <td>63.970015</td>
      <td>1891870.591</td>
      <td>363513.0314</td>
      <td>0.277988</td>
      <td>41.426755</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2017 - Period:3</td>
      <td>286.705586</td>
      <td>1.666666e-05</td>
      <td>0.000020</td>
      <td>0.192991</td>
      <td>96.428571</td>
      <td>43.550</td>
      <td>0.2400</td>
      <td>9.746</td>
      <td>0.022129</td>
      <td>...</td>
      <td>0.027000</td>
      <td>39.484454</td>
      <td>107.705523</td>
      <td>38.892340</td>
      <td>44.824094</td>
      <td>68.547790</td>
      <td>2004044.027</td>
      <td>383228.1569</td>
      <td>0.147320</td>
      <td>43.313327</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2017 - Period:4</td>
      <td>361.444714</td>
      <td>6.651401e+06</td>
      <td>120894.503000</td>
      <td>0.172487</td>
      <td>100.000000</td>
      <td>53.150</td>
      <td>0.7400</td>
      <td>9.979</td>
      <td>0.020740</td>
      <td>...</td>
      <td>0.043500</td>
      <td>37.077228</td>
      <td>99.551161</td>
      <td>35.663013</td>
      <td>41.098260</td>
      <td>62.129173</td>
      <td>2148189.370</td>
      <td>459954.8066</td>
      <td>0.197980</td>
      <td>40.338916</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2017 - Period:5</td>
      <td>378.273911</td>
      <td>8.910372e+06</td>
      <td>182109.363900</td>
      <td>21.078521</td>
      <td>69.565217</td>
      <td>57.250</td>
      <td>0.6175</td>
      <td>10.046</td>
      <td>0.017931</td>
      <td>...</td>
      <td>0.028700</td>
      <td>38.071712</td>
      <td>103.701047</td>
      <td>33.497936</td>
      <td>41.822179</td>
      <td>61.962594</td>
      <td>2374795.883</td>
      <td>645477.0960</td>
      <td>0.077999</td>
      <td>43.104438</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2017 - Period:7</td>
      <td>367.547047</td>
      <td>9.058154e+06</td>
      <td>207179.200500</td>
      <td>15.463010</td>
      <td>90.000000</td>
      <td>75.050</td>
      <td>0.6000</td>
      <td>9.624</td>
      <td>0.015434</td>
      <td>...</td>
      <td>0.039100</td>
      <td>39.074158</td>
      <td>102.255447</td>
      <td>38.969515</td>
      <td>44.278643</td>
      <td>66.466043</td>
      <td>2727062.938</td>
      <td>799657.5538</td>
      <td>0.108390</td>
      <td>43.770566</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2017 - Period:8</td>
      <td>385.537890</td>
      <td>3.623262e+06</td>
      <td>103589.600300</td>
      <td>4.101180</td>
      <td>100.000000</td>
      <td>74.250</td>
      <td>0.4650</td>
      <td>9.777</td>
      <td>0.016439</td>
      <td>...</td>
      <td>0.037900</td>
      <td>39.210046</td>
      <td>103.590606</td>
      <td>35.383466</td>
      <td>45.019460</td>
      <td>67.801091</td>
      <td>2606894.637</td>
      <td>746305.3712</td>
      <td>0.107745</td>
      <td>44.201566</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2017 - Period:9</td>
      <td>332.150377</td>
      <td>1.449305e+06</td>
      <td>51794.800150</td>
      <td>2.681315</td>
      <td>63.840830</td>
      <td>71.100</td>
      <td>0.2900</td>
      <td>10.278</td>
      <td>0.018580</td>
      <td>...</td>
      <td>0.032800</td>
      <td>39.933452</td>
      <td>103.845387</td>
      <td>37.592478</td>
      <td>45.444195</td>
      <td>66.662304</td>
      <td>2266495.228</td>
      <td>569190.0087</td>
      <td>0.107923</td>
      <td>45.042135</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2017 - Period:10</td>
      <td>237.713584</td>
      <td>5.797219e+05</td>
      <td>25897.400090</td>
      <td>6.950823</td>
      <td>100.000000</td>
      <td>68.900</td>
      <td>0.1050</td>
      <td>10.933</td>
      <td>0.020216</td>
      <td>...</td>
      <td>0.009970</td>
      <td>42.153482</td>
      <td>115.790025</td>
      <td>40.999141</td>
      <td>48.515070</td>
      <td>75.555801</td>
      <td>1997388.511</td>
      <td>425334.0232</td>
      <td>0.048579</td>
      <td>46.154296</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2017 - Period:11</td>
      <td>193.300754</td>
      <td>2.318887e+05</td>
      <td>12948.700050</td>
      <td>21.163171</td>
      <td>100.000000</td>
      <td>57.350</td>
      <td>0.5675</td>
      <td>10.423</td>
      <td>0.018727</td>
      <td>...</td>
      <td>0.000338</td>
      <td>43.815100</td>
      <td>119.232494</td>
      <td>49.597988</td>
      <td>50.253280</td>
      <td>73.352137</td>
      <td>1882591.148</td>
      <td>343376.7067</td>
      <td>0.001927</td>
      <td>47.522960</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2017 - Period:12</td>
      <td>179.292503</td>
      <td>9.275550e+04</td>
      <td>6474.350036</td>
      <td>9.209103</td>
      <td>100.000000</td>
      <td>44.050</td>
      <td>0.1650</td>
      <td>10.710</td>
      <td>0.020428</td>
      <td>...</td>
      <td>0.000238</td>
      <td>43.466286</td>
      <td>121.780734</td>
      <td>47.322239</td>
      <td>48.110003</td>
      <td>73.753357</td>
      <td>1666900.398</td>
      <td>282930.3995</td>
      <td>0.001659</td>
      <td>47.229715</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2017 - Period:13</td>
      <td>173.237305</td>
      <td>3.710220e+04</td>
      <td>3237.175028</td>
      <td>31.371231</td>
      <td>100.000000</td>
      <td>36.250</td>
      <td>0.1900</td>
      <td>10.375</td>
      <td>0.019739</td>
      <td>...</td>
      <td>0.001310</td>
      <td>43.829172</td>
      <td>121.889647</td>
      <td>57.797794</td>
      <td>50.753726</td>
      <td>72.367832</td>
      <td>1610351.525</td>
      <td>258255.9299</td>
      <td>0.011639</td>
      <td>46.751959</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2018 - Period:2</td>
      <td>284.183292</td>
      <td>5.936352e+03</td>
      <td>809.293772</td>
      <td>22.392944</td>
      <td>20.000000</td>
      <td>37.550</td>
      <td>0.4900</td>
      <td>10.876</td>
      <td>0.021614</td>
      <td>...</td>
      <td>0.069000</td>
      <td>39.458459</td>
      <td>110.924954</td>
      <td>42.064624</td>
      <td>50.630673</td>
      <td>66.774216</td>
      <td>1791357.204</td>
      <td>340550.0339</td>
      <td>0.430051</td>
      <td>42.908150</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2018 - Period:3</td>
      <td>274.430757</td>
      <td>2.374541e+03</td>
      <td>404.646896</td>
      <td>0.407851</td>
      <td>100.000000</td>
      <td>39.900</td>
      <td>0.3150</td>
      <td>10.738</td>
      <td>0.021428</td>
      <td>...</td>
      <td>0.070100</td>
      <td>32.483718</td>
      <td>89.649801</td>
      <td>33.664065</td>
      <td>41.940948</td>
      <td>57.583497</td>
      <td>1919431.786</td>
      <td>384255.6322</td>
      <td>0.328797</td>
      <td>35.480731</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2018 - Period:4</td>
      <td>205.499984</td>
      <td>9.498163e+02</td>
      <td>202.323458</td>
      <td>0.297397</td>
      <td>81.250000</td>
      <td>45.900</td>
      <td>0.3300</td>
      <td>11.255</td>
      <td>0.022549</td>
      <td>...</td>
      <td>0.011600</td>
      <td>37.441358</td>
      <td>100.689675</td>
      <td>37.943627</td>
      <td>47.562541</td>
      <td>63.897266</td>
      <td>2010362.037</td>
      <td>468177.8792</td>
      <td>0.047280</td>
      <td>40.796769</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2018 - Period:5</td>
      <td>250.555064</td>
      <td>3.799265e+02</td>
      <td>101.161739</td>
      <td>0.451806</td>
      <td>70.588235</td>
      <td>62.425</td>
      <td>0.3950</td>
      <td>11.784</td>
      <td>0.024541</td>
      <td>...</td>
      <td>0.028200</td>
      <td>36.334860</td>
      <td>97.010689</td>
      <td>36.125513</td>
      <td>44.807220</td>
      <td>59.016867</td>
      <td>2242374.168</td>
      <td>607623.5341</td>
      <td>0.079705</td>
      <td>39.629488</td>
    </tr>
    <tr>
      <th>28</th>
      <td>2018 - Period:7</td>
      <td>284.895480</td>
      <td>6.567261e+06</td>
      <td>87161.490440</td>
      <td>19.138407</td>
      <td>100.000000</td>
      <td>75.750</td>
      <td>0.5450</td>
      <td>11.732</td>
      <td>0.026716</td>
      <td>...</td>
      <td>0.033200</td>
      <td>33.876058</td>
      <td>83.883480</td>
      <td>32.368993</td>
      <td>38.550768</td>
      <td>57.739764</td>
      <td>2747208.438</td>
      <td>856242.9394</td>
      <td>0.087384</td>
      <td>37.304607</td>
    </tr>
    <tr>
      <th>29</th>
      <td>2018 - Period:8</td>
      <td>244.931359</td>
      <td>1.111330e+07</td>
      <td>98714.345220</td>
      <td>11.599931</td>
      <td>66.666667</td>
      <td>75.850</td>
      <td>0.6100</td>
      <td>11.708</td>
      <td>0.025758</td>
      <td>...</td>
      <td>0.019800</td>
      <td>35.601937</td>
      <td>87.364884</td>
      <td>34.230754</td>
      <td>41.671473</td>
      <td>60.732023</td>
      <td>2494566.851</td>
      <td>718652.2126</td>
      <td>0.058438</td>
      <td>39.036294</td>
    </tr>
    <tr>
      <th>30</th>
      <td>2018 - Period:9</td>
      <td>175.432319</td>
      <td>1.205852e+07</td>
      <td>97390.772610</td>
      <td>14.095678</td>
      <td>100.000000</td>
      <td>76.450</td>
      <td>0.5900</td>
      <td>11.630</td>
      <td>0.023499</td>
      <td>...</td>
      <td>0.001670</td>
      <td>39.793671</td>
      <td>100.829616</td>
      <td>39.401185</td>
      <td>45.600532</td>
      <td>69.429912</td>
      <td>2229095.053</td>
      <td>577838.0553</td>
      <td>0.005625</td>
      <td>43.413995</td>
    </tr>
    <tr>
      <th>31</th>
      <td>2018 - Period:10</td>
      <td>168.106665</td>
      <td>4.823409e+06</td>
      <td>48695.386310</td>
      <td>0.578009</td>
      <td>72.131148</td>
      <td>70.200</td>
      <td>0.4750</td>
      <td>11.703</td>
      <td>0.021597</td>
      <td>...</td>
      <td>0.002180</td>
      <td>37.886247</td>
      <td>100.392136</td>
      <td>43.794535</td>
      <td>46.984350</td>
      <td>67.336423</td>
      <td>1855904.292</td>
      <td>414953.9342</td>
      <td>0.009904</td>
      <td>40.993750</td>
    </tr>
    <tr>
      <th>32</th>
      <td>2018 - Period:12</td>
      <td>151.642231</td>
      <td>7.717454e+05</td>
      <td>12173.846590</td>
      <td>47.442188</td>
      <td>63.499498</td>
      <td>46.700</td>
      <td>0.1300</td>
      <td>10.943</td>
      <td>0.020236</td>
      <td>...</td>
      <td>0.025400</td>
      <td>35.160039</td>
      <td>94.348743</td>
      <td>36.397584</td>
      <td>42.892464</td>
      <td>59.837492</td>
      <td>1565306.078</td>
      <td>272019.8263</td>
      <td>0.164554</td>
      <td>37.554776</td>
    </tr>
    <tr>
      <th>33</th>
      <td>2018 - Period:13</td>
      <td>130.937361</td>
      <td>3.086982e+05</td>
      <td>6086.923307</td>
      <td>32.880430</td>
      <td>35.714286</td>
      <td>35.875</td>
      <td>0.2850</td>
      <td>12.286</td>
      <td>0.018484</td>
      <td>...</td>
      <td>0.016800</td>
      <td>35.157519</td>
      <td>94.349506</td>
      <td>40.115247</td>
      <td>41.117279</td>
      <td>58.656090</td>
      <td>1504338.620</td>
      <td>249237.4935</td>
      <td>0.139243</td>
      <td>37.297355</td>
    </tr>
  </tbody>
</table>
<p>34 rows × 28 columns</p>
</div>




```python
data_new.drop(['Period'],axis=1,inplace=True)
```

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\frame.py:3694: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      errors=errors)
    


```python
data_new.columns
```




    Index(['EQ', 'Print_Impressions.Ads40', 'Print_Working_Cost.Ads50', 'SOS_pct',
           'CCFOT', 'Median_Temp', 'Median_Rainfall', 'Fuel_Price', 'Inflation',
           'Trade_Invest', 'Brand_Equity', 'Avg_EQ_Price', 'Any_Promo_pct_ACV',
           'EQ_Base_Price', 'Est_ACV_Selling', 'pct_ACV', 'Avg_no_of_Items',
           'pct_PromoMarketDollars_Category', 'RPI_Category', 'Competitor1_RPI',
           'Competitor2_RPI', 'Competitor3_RPI', 'Competitor4_RPI', 'EQ_Category',
           'EQ_Subcategory', 'pct_PromoMarketDollars_Subcategory',
           'RPI_Subcategory'],
          dtype='object')




```python
sns.pairplot(data_new)
```




    <seaborn.axisgrid.PairGrid at 0x1ea2aa7d2e8>




![png](output_17_1.png)



```python
corr = data_new.corr()
ax = sns.heatmap(corr,vmin=-1, vmax=1,center=0,cmap=sns.diverging_palette(20, 220, n=200),square=True)
ax.set_xticklabels(ax.get_xticklabels(),rotation=45,horizontalalignment='right')
```




    [Text(0.5, 0, 'EQ'),
     Text(2.5, 0, 'Print_Working_Cost.Ads50'),
     Text(4.5, 0, 'CCFOT'),
     Text(6.5, 0, 'Median_Rainfall'),
     Text(8.5, 0, 'Inflation'),
     Text(10.5, 0, 'Brand_Equity'),
     Text(12.5, 0, 'Any_Promo_pct_ACV'),
     Text(14.5, 0, 'Est_ACV_Selling'),
     Text(16.5, 0, 'Avg_no_of_Items'),
     Text(18.5, 0, 'RPI_Category'),
     Text(20.5, 0, 'Competitor2_RPI'),
     Text(22.5, 0, 'Competitor4_RPI'),
     Text(24.5, 0, 'EQ_Subcategory'),
     Text(26.5, 0, 'RPI_Subcategory')]




![png](output_18_1.png)



```python
x_data=data_new[['Print_Impressions.Ads40', 'Print_Working_Cost.Ads50', 'SOS_pct',
       'CCFOT', 'Median_Temp', 'Median_Rainfall', 'Fuel_Price', 'Inflation',
       'Trade_Invest', 'Brand_Equity', 'Avg_EQ_Price', 'Any_Promo_pct_ACV',
       'EQ_Base_Price', 'Est_ACV_Selling', 'pct_ACV', 'Avg_no_of_Items',
       'pct_PromoMarketDollars_Category', 'RPI_Category', 'Competitor1_RPI',
       'Competitor2_RPI', 'Competitor3_RPI', 'Competitor4_RPI', 'EQ_Category',
       'EQ_Subcategory', 'pct_PromoMarketDollars_Subcategory',
       'RPI_Subcategory']]
y_data=data_new['EQ']
```


```python
data_new.describe(percentiles = [0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,1]).T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>0%</th>
      <th>10%</th>
      <th>20%</th>
      <th>30%</th>
      <th>40%</th>
      <th>50%</th>
      <th>60%</th>
      <th>70%</th>
      <th>80%</th>
      <th>90%</th>
      <th>95%</th>
      <th>99%</th>
      <th>100%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>EQ</th>
      <td>34.0</td>
      <td>3.237141e+02</td>
      <td>1.215124e+02</td>
      <td>1.309374e+02</td>
      <td>1.309374e+02</td>
      <td>1.738958e+02</td>
      <td>2.006203e+02</td>
      <td>2.443614e+02</td>
      <td>2.838746e+02</td>
      <td>2.926294e+02</td>
      <td>3.572494e+02</td>
      <td>3.790003e+02</td>
      <td>4.706524e+02</td>
      <td>4.886968e+02</td>
      <td>4.953219e+02</td>
      <td>5.324346e+02</td>
      <td>5.460531e+02</td>
      <td>5.460531e+02</td>
    </tr>
    <tr>
      <th>Print_Impressions.Ads40</th>
      <td>34.0</td>
      <td>2.008683e+06</td>
      <td>3.585173e+06</td>
      <td>1.400000e-05</td>
      <td>1.400000e-05</td>
      <td>1.652672e-05</td>
      <td>1.665968e-05</td>
      <td>1.666635e-05</td>
      <td>7.598532e+01</td>
      <td>4.155446e+03</td>
      <td>2.040621e+05</td>
      <td>8.395013e+05</td>
      <td>4.103320e+06</td>
      <td>8.232681e+06</td>
      <td>9.777457e+06</td>
      <td>1.174660e+07</td>
      <td>1.205852e+07</td>
      <td>1.205852e+07</td>
    </tr>
    <tr>
      <th>Print_Working_Cost.Ads50</th>
      <td>34.0</td>
      <td>3.229895e+04</td>
      <td>5.503839e+04</td>
      <td>1.500000e-05</td>
      <td>1.500000e-05</td>
      <td>1.946875e-05</td>
      <td>1.994531e-05</td>
      <td>1.999463e-05</td>
      <td>2.023236e+01</td>
      <td>6.069703e+02</td>
      <td>6.396865e+03</td>
      <td>2.653755e+04</td>
      <td>6.594148e+04</td>
      <td>1.021270e+05</td>
      <td>1.423197e+05</td>
      <td>1.989062e+05</td>
      <td>2.071792e+05</td>
      <td>2.071792e+05</td>
    </tr>
    <tr>
      <th>SOS_pct</th>
      <td>34.0</td>
      <td>1.192692e+01</td>
      <td>1.154759e+01</td>
      <td>1.028581e-01</td>
      <td>1.028581e-01</td>
      <td>2.635577e-01</td>
      <td>5.275276e-01</td>
      <td>2.643134e+00</td>
      <td>7.050035e+00</td>
      <td>1.040452e+01</td>
      <td>1.351753e+01</td>
      <td>1.538482e+01</td>
      <td>2.111238e+01</td>
      <td>2.685041e+01</td>
      <td>3.189945e+01</td>
      <td>4.263681e+01</td>
      <td>4.744219e+01</td>
      <td>4.744219e+01</td>
    </tr>
    <tr>
      <th>CCFOT</th>
      <td>34.0</td>
      <td>8.718739e+01</td>
      <td>1.965339e+01</td>
      <td>2.000000e+01</td>
      <td>2.000000e+01</td>
      <td>6.468858e+01</td>
      <td>7.151398e+01</td>
      <td>8.427885e+01</td>
      <td>9.120000e+01</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
      <td>1.000000e+02</td>
    </tr>
    <tr>
      <th>Median_Temp</th>
      <td>34.0</td>
      <td>5.652500e+01</td>
      <td>1.536585e+01</td>
      <td>3.295000e+01</td>
      <td>3.295000e+01</td>
      <td>3.598750e+01</td>
      <td>4.053000e+01</td>
      <td>4.571500e+01</td>
      <td>4.941000e+01</td>
      <td>5.730000e+01</td>
      <td>6.195500e+01</td>
      <td>7.028500e+01</td>
      <td>7.392000e+01</td>
      <td>7.582000e+01</td>
      <td>7.606000e+01</td>
      <td>7.705300e+01</td>
      <td>7.735000e+01</td>
      <td>7.735000e+01</td>
    </tr>
    <tr>
      <th>Median_Rainfall</th>
      <td>34.0</td>
      <td>3.926471e-01</td>
      <td>1.699386e-01</td>
      <td>9.500000e-02</td>
      <td>9.500000e-02</td>
      <td>1.615000e-01</td>
      <td>2.445000e-01</td>
      <td>2.895000e-01</td>
      <td>3.340000e-01</td>
      <td>3.925000e-01</td>
      <td>4.640000e-01</td>
      <td>5.037500e-01</td>
      <td>5.570000e-01</td>
      <td>5.970000e-01</td>
      <td>6.126250e-01</td>
      <td>6.995750e-01</td>
      <td>7.400000e-01</td>
      <td>7.400000e-01</td>
    </tr>
    <tr>
      <th>Fuel_Price</th>
      <td>34.0</td>
      <td>1.009379e+01</td>
      <td>1.158548e+00</td>
      <td>7.473000e+00</td>
      <td>7.473000e+00</td>
      <td>8.881300e+00</td>
      <td>9.256200e+00</td>
      <td>9.460000e+00</td>
      <td>9.665200e+00</td>
      <td>9.901500e+00</td>
      <td>1.035560e+01</td>
      <td>1.075180e+01</td>
      <td>1.106780e+01</td>
      <td>1.170650e+01</td>
      <td>1.175020e+01</td>
      <td>1.212034e+01</td>
      <td>1.228600e+01</td>
      <td>1.228600e+01</td>
    </tr>
    <tr>
      <th>Inflation</th>
      <td>34.0</td>
      <td>1.750207e-02</td>
      <td>5.659181e-03</td>
      <td>7.832481e-03</td>
      <td>7.832481e-03</td>
      <td>9.367129e-03</td>
      <td>1.062662e-02</td>
      <td>1.488253e-02</td>
      <td>1.673720e-02</td>
      <td>1.863855e-02</td>
      <td>2.012090e-02</td>
      <td>2.080862e-02</td>
      <td>2.182000e-02</td>
      <td>2.422871e-02</td>
      <td>2.609331e-02</td>
      <td>2.682829e-02</td>
      <td>2.688364e-02</td>
      <td>2.688364e-02</td>
    </tr>
    <tr>
      <th>Trade_Invest</th>
      <td>34.0</td>
      <td>1.555812e+04</td>
      <td>1.984580e+04</td>
      <td>3.654300e+02</td>
      <td>3.654300e+02</td>
      <td>5.773900e+02</td>
      <td>7.783340e+02</td>
      <td>9.013390e+02</td>
      <td>1.062620e+03</td>
      <td>1.625310e+03</td>
      <td>4.341462e+03</td>
      <td>2.599722e+04</td>
      <td>3.552818e+04</td>
      <td>4.220470e+04</td>
      <td>5.336269e+04</td>
      <td>5.902274e+04</td>
      <td>6.167532e+04</td>
      <td>6.167532e+04</td>
    </tr>
    <tr>
      <th>Brand_Equity</th>
      <td>34.0</td>
      <td>4.337730e+01</td>
      <td>7.474588e-01</td>
      <td>4.214000e+01</td>
      <td>4.214000e+01</td>
      <td>4.241000e+01</td>
      <td>4.254000e+01</td>
      <td>4.278000e+01</td>
      <td>4.337000e+01</td>
      <td>4.356821e+01</td>
      <td>4.361000e+01</td>
      <td>4.386286e+01</td>
      <td>4.417000e+01</td>
      <td>4.430000e+01</td>
      <td>4.435250e+01</td>
      <td>4.445000e+01</td>
      <td>4.445000e+01</td>
      <td>4.445000e+01</td>
    </tr>
    <tr>
      <th>Avg_EQ_Price</th>
      <td>34.0</td>
      <td>5.207198e+01</td>
      <td>3.842254e+00</td>
      <td>4.478257e+01</td>
      <td>4.478257e+01</td>
      <td>4.901236e+01</td>
      <td>4.934405e+01</td>
      <td>4.980495e+01</td>
      <td>5.066137e+01</td>
      <td>5.121948e+01</td>
      <td>5.181506e+01</td>
      <td>5.354470e+01</td>
      <td>5.448757e+01</td>
      <td>5.797560e+01</td>
      <td>6.018770e+01</td>
      <td>6.063638e+01</td>
      <td>6.067787e+01</td>
      <td>6.067787e+01</td>
    </tr>
    <tr>
      <th>Any_Promo_pct_ACV</th>
      <td>34.0</td>
      <td>7.121763e+00</td>
      <td>3.800814e+00</td>
      <td>3.286449e-01</td>
      <td>3.286449e-01</td>
      <td>1.476518e+00</td>
      <td>3.417955e+00</td>
      <td>6.085462e+00</td>
      <td>7.149802e+00</td>
      <td>7.736179e+00</td>
      <td>8.108681e+00</td>
      <td>8.607318e+00</td>
      <td>9.526280e+00</td>
      <td>1.112501e+01</td>
      <td>1.331017e+01</td>
      <td>1.558858e+01</td>
      <td>1.653845e+01</td>
      <td>1.653845e+01</td>
    </tr>
    <tr>
      <th>EQ_Base_Price</th>
      <td>34.0</td>
      <td>1.527666e+00</td>
      <td>9.199717e-02</td>
      <td>1.423408e+00</td>
      <td>1.423408e+00</td>
      <td>1.431215e+00</td>
      <td>1.443127e+00</td>
      <td>1.455532e+00</td>
      <td>1.474186e+00</td>
      <td>1.490983e+00</td>
      <td>1.529509e+00</td>
      <td>1.588079e+00</td>
      <td>1.621032e+00</td>
      <td>1.670678e+00</td>
      <td>1.689625e+00</td>
      <td>1.702136e+00</td>
      <td>1.702518e+00</td>
      <td>1.702518e+00</td>
    </tr>
    <tr>
      <th>Est_ACV_Selling</th>
      <td>34.0</td>
      <td>6.004528e+09</td>
      <td>2.095679e+09</td>
      <td>2.904612e+09</td>
      <td>2.904612e+09</td>
      <td>3.213569e+09</td>
      <td>3.478243e+09</td>
      <td>4.717844e+09</td>
      <td>5.362326e+09</td>
      <td>5.615173e+09</td>
      <td>7.301577e+09</td>
      <td>7.631068e+09</td>
      <td>8.558102e+09</td>
      <td>8.661976e+09</td>
      <td>8.687305e+09</td>
      <td>8.703495e+09</td>
      <td>8.706898e+09</td>
      <td>8.706898e+09</td>
    </tr>
    <tr>
      <th>pct_ACV</th>
      <td>34.0</td>
      <td>2.604531e+01</td>
      <td>9.490019e+00</td>
      <td>1.303606e+01</td>
      <td>1.303606e+01</td>
      <td>1.361156e+01</td>
      <td>1.427491e+01</td>
      <td>2.078580e+01</td>
      <td>2.393809e+01</td>
      <td>2.470477e+01</td>
      <td>3.039275e+01</td>
      <td>3.220521e+01</td>
      <td>3.707568e+01</td>
      <td>3.856586e+01</td>
      <td>3.904575e+01</td>
      <td>3.932774e+01</td>
      <td>3.944102e+01</td>
      <td>3.944102e+01</td>
    </tr>
    <tr>
      <th>Avg_no_of_Items</th>
      <td>34.0</td>
      <td>2.440383e+00</td>
      <td>1.072856e-01</td>
      <td>2.075661e+00</td>
      <td>2.075661e+00</td>
      <td>2.355701e+00</td>
      <td>2.372174e+00</td>
      <td>2.390926e+00</td>
      <td>2.415000e+00</td>
      <td>2.437324e+00</td>
      <td>2.445318e+00</td>
      <td>2.495992e+00</td>
      <td>2.508372e+00</td>
      <td>2.562705e+00</td>
      <td>2.622276e+00</td>
      <td>2.656944e+00</td>
      <td>2.664421e+00</td>
      <td>2.664421e+00</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Category</th>
      <td>34.0</td>
      <td>2.286253e-02</td>
      <td>1.851720e-02</td>
      <td>2.380000e-04</td>
      <td>2.380000e-04</td>
      <td>1.793000e-03</td>
      <td>4.888000e-03</td>
      <td>9.738000e-03</td>
      <td>1.512000e-02</td>
      <td>2.235000e-02</td>
      <td>2.796000e-02</td>
      <td>3.064000e-02</td>
      <td>3.550000e-02</td>
      <td>4.218000e-02</td>
      <td>5.652000e-02</td>
      <td>6.973700e-02</td>
      <td>7.010000e-02</td>
      <td>7.010000e-02</td>
    </tr>
    <tr>
      <th>RPI_Category</th>
      <td>34.0</td>
      <td>3.844544e+01</td>
      <td>2.616143e+00</td>
      <td>3.248372e+01</td>
      <td>3.248372e+01</td>
      <td>3.529261e+01</td>
      <td>3.636738e+01</td>
      <td>3.736153e+01</td>
      <td>3.807956e+01</td>
      <td>3.848567e+01</td>
      <td>3.918287e+01</td>
      <td>3.949558e+01</td>
      <td>3.976429e+01</td>
      <td>4.181372e+01</td>
      <td>4.358837e+01</td>
      <td>4.382453e+01</td>
      <td>4.382917e+01</td>
      <td>4.382917e+01</td>
    </tr>
    <tr>
      <th>Competitor1_RPI</th>
      <td>34.0</td>
      <td>1.021461e+02</td>
      <td>8.806682e+00</td>
      <td>8.388348e+01</td>
      <td>8.388348e+01</td>
      <td>9.434897e+01</td>
      <td>9.633423e+01</td>
      <td>9.778302e+01</td>
      <td>9.991563e+01</td>
      <td>1.007596e+02</td>
      <td>1.022343e+02</td>
      <td>1.039640e+02</td>
      <td>1.075832e+02</td>
      <td>1.144840e+02</td>
      <td>1.201244e+02</td>
      <td>1.218537e+02</td>
      <td>1.218896e+02</td>
      <td>1.218896e+02</td>
    </tr>
    <tr>
      <th>Competitor2_RPI</th>
      <td>34.0</td>
      <td>3.887596e+01</td>
      <td>5.196502e+00</td>
      <td>3.236899e+01</td>
      <td>3.236899e+01</td>
      <td>3.407854e+01</td>
      <td>3.548781e+01</td>
      <td>3.602428e+01</td>
      <td>3.666020e+01</td>
      <td>3.734603e+01</td>
      <td>3.870260e+01</td>
      <td>3.948471e+01</td>
      <td>4.087999e+01</td>
      <td>4.575749e+01</td>
      <td>4.811875e+01</td>
      <td>5.509186e+01</td>
      <td>5.779779e+01</td>
      <td>5.779779e+01</td>
    </tr>
    <tr>
      <th>Competitor3_RPI</th>
      <td>34.0</td>
      <td>4.444123e+01</td>
      <td>2.978976e+00</td>
      <td>3.855077e+01</td>
      <td>3.855077e+01</td>
      <td>4.118912e+01</td>
      <td>4.176190e+01</td>
      <td>4.253627e+01</td>
      <td>4.354246e+01</td>
      <td>4.460692e+01</td>
      <td>4.482072e+01</td>
      <td>4.545983e+01</td>
      <td>4.642681e+01</td>
      <td>4.839355e+01</td>
      <td>5.038537e+01</td>
      <td>5.071312e+01</td>
      <td>5.075373e+01</td>
      <td>5.075373e+01</td>
    </tr>
    <tr>
      <th>Competitor4_RPI</th>
      <td>34.0</td>
      <td>6.528162e+01</td>
      <td>4.541603e+00</td>
      <td>5.758350e+01</td>
      <td>5.758350e+01</td>
      <td>5.926305e+01</td>
      <td>6.203929e+01</td>
      <td>6.321095e+01</td>
      <td>6.348127e+01</td>
      <td>6.490190e+01</td>
      <td>6.662305e+01</td>
      <td>6.735628e+01</td>
      <td>6.846868e+01</td>
      <td>7.155485e+01</td>
      <td>7.349256e+01</td>
      <td>7.496099e+01</td>
      <td>7.555580e+01</td>
      <td>7.555580e+01</td>
    </tr>
    <tr>
      <th>EQ_Category</th>
      <td>34.0</td>
      <td>2.116786e+06</td>
      <td>3.923903e+05</td>
      <td>1.504339e+06</td>
      <td>1.504339e+06</td>
      <td>1.639987e+06</td>
      <td>1.777509e+06</td>
      <td>1.890943e+06</td>
      <td>1.943854e+06</td>
      <td>2.013858e+06</td>
      <td>2.141278e+06</td>
      <td>2.277325e+06</td>
      <td>2.462977e+06</td>
      <td>2.741165e+06</td>
      <td>2.802740e+06</td>
      <td>2.849549e+06</td>
      <td>2.867307e+06</td>
      <td>2.867307e+06</td>
    </tr>
    <tr>
      <th>EQ_Subcategory</th>
      <td>34.0</td>
      <td>4.912062e+05</td>
      <td>1.909215e+05</td>
      <td>2.492375e+05</td>
      <td>2.492375e+05</td>
      <td>2.752930e+05</td>
      <td>3.335378e+05</td>
      <td>3.491723e+05</td>
      <td>3.848342e+05</td>
      <td>4.232342e+05</td>
      <td>4.796273e+05</td>
      <td>6.067532e+05</td>
      <td>6.747471e+05</td>
      <td>7.964932e+05</td>
      <td>8.140209e+05</td>
      <td>8.471789e+05</td>
      <td>8.562429e+05</td>
      <td>8.562429e+05</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Subcategory</th>
      <td>34.0</td>
      <td>1.010328e-01</td>
      <td>9.859795e-02</td>
      <td>1.658878e-03</td>
      <td>1.658878e-03</td>
      <td>1.036487e-02</td>
      <td>2.387770e-02</td>
      <td>3.564239e-02</td>
      <td>5.697022e-02</td>
      <td>7.885227e-02</td>
      <td>9.921729e-02</td>
      <td>1.100902e-01</td>
      <td>1.534848e-01</td>
      <td>2.215489e-01</td>
      <td>2.957714e-01</td>
      <td>3.966370e-01</td>
      <td>4.300507e-01</td>
      <td>4.300507e-01</td>
    </tr>
    <tr>
      <th>RPI_Subcategory</th>
      <td>34.0</td>
      <td>4.233519e+01</td>
      <td>2.921126e+00</td>
      <td>3.548073e+01</td>
      <td>3.548073e+01</td>
      <td>3.799923e+01</td>
      <td>4.022187e+01</td>
      <td>4.077315e+01</td>
      <td>4.232275e+01</td>
      <td>4.294134e+01</td>
      <td>4.333913e+01</td>
      <td>4.378611e+01</td>
      <td>4.433806e+01</td>
      <td>4.582985e+01</td>
      <td>4.691917e+01</td>
      <td>4.742619e+01</td>
      <td>4.752296e+01</td>
      <td>4.752296e+01</td>
    </tr>
  </tbody>
</table>
</div>



### Outlier Treatment


```python
x_data = x_data.div(x_data.quantile(.99)).clip_upper(1)
print (x_data)
```

        Print_Impressions.Ads40  Print_Working_Cost.Ads50   SOS_pct     CCFOT  \
    0              1.710012e-01              1.623828e-01  0.174659  1.000000   
    1              1.191834e-12              7.541245e-11  0.273873  0.875000   
    2              1.328044e-12              8.798119e-11  0.002412  0.960000   
    3              1.382528e-12              9.426556e-11  0.005841  1.000000   
    4              1.404321e-12              9.740775e-11  0.312847  1.000000   
    5              1.413039e-12              9.897884e-11  0.318087  0.785714   
    6              1.416526e-12              9.976438e-11  0.337556  0.880000   
    7              1.417920e-12              1.001572e-10  0.360630  0.846154   
    8              1.418478e-12              1.003535e-10  0.537858  1.000000   
    9              1.418702e-12              1.004517e-10  0.669128  1.000000   
    10             1.418791e-12              1.005008e-10  0.193099  1.000000   
    11             1.418826e-12              1.005254e-10  0.053932  1.000000   
    12             1.418841e-12              1.005377e-10  0.100971  1.000000   
    13             1.418849e-12              1.005469e-10  0.032879  1.000000   
    14             1.418850e-12              1.005484e-10  0.004526  0.964286   
    15             5.662405e-01              6.077967e-01  0.004046  1.000000   
    16             7.585490e-01              9.155542e-01  0.494374  0.695652   
    17             7.711299e-01              1.000000e+00  0.362668  0.900000   
    18             3.084519e-01              5.207964e-01  0.096189  1.000000   
    19             1.233808e-01              2.603982e-01  0.062887  0.638408   
    20             4.935231e-02              1.301991e-01  0.163024  1.000000   
    21             1.974092e-02              6.509954e-02  0.496359  1.000000   
    22             7.896370e-03              3.254977e-02  0.215990  1.000000   
    23             3.158548e-03              1.627489e-02  0.735778  1.000000   
    24             5.053677e-04              4.068722e-03  0.525202  0.200000   
    25             2.021471e-04              2.034361e-03  0.009566  1.000000   
    26             8.085883e-05              1.017180e-03  0.006975  0.812500   
    27             3.234353e-05              5.085903e-04  0.010597  0.705882   
    28             5.590776e-01              4.382041e-01  0.448871  1.000000   
    29             9.460869e-01              4.962860e-01  0.272064  0.666667   
    30             1.000000e+00              4.896318e-01  0.330599  1.000000   
    31             4.106217e-01              2.448159e-01  0.013557  0.721311   
    32             6.569947e-02              6.120397e-02  1.000000  0.634995   
    33             2.627979e-02              3.060199e-02  0.771175  0.357143   
    
        Median_Temp  Median_Rainfall  Fuel_Price  Inflation  Trade_Invest  \
    0      0.427628         0.736161    0.678694   0.494182      0.724200   
    1      0.449366         0.385949    0.616567   0.370448      0.614855   
    2      0.606076         0.557481    0.660130   0.291949      0.590487   
    3      0.644362         0.500304    0.723330   0.374019      0.421356   
    4      0.754026         0.718293    0.765408   0.355831      1.000000   
    5      0.888998         0.657542    0.810538   0.346288      0.685475   
    6      0.956484         0.607512    0.795522   0.308774      0.693728   
    7      1.000000         0.793339    0.754764   0.315387      0.373187   
    8      0.984387         0.800486    0.761117   0.410817      0.901600   
    9      0.922093         0.421685    0.769863   0.520555      0.429380   
    10     0.779658         0.228710    0.779021   0.558530      0.908755   
    11     0.640468         0.135797    0.757404   0.599612      0.593331   
    12     0.460722         0.543187    0.780671   0.696905      0.540187   
    13     0.531452         0.353786    0.795770   1.000000      0.007704   
    14     0.565195         0.343065    0.804103   0.824848      0.019442   
    15     0.689785         1.000000    0.823327   0.773057      0.010214   
    16     0.742995         0.882679    0.828855   0.668368      0.014864   
    17     0.974005         0.857664    0.794037   0.575299      0.016611   
    18     0.963622         0.664689    0.806661   0.612738      0.012558   
    19     0.922741         0.414537    0.847996   0.692565      0.015783   
    20     0.894190         0.150091    0.902037   0.753550      0.013606   
    21     0.744293         0.811207    0.859959   0.698027      0.008382   
    22     0.571684         0.235857    0.883639   0.761433      0.019623   
    23     0.470455         0.271593    0.855999   0.735742      0.011919   
    24     0.487327         0.700425    0.897335   0.805636      0.079161   
    25     0.517825         0.450273    0.885949   0.798713      0.033668   
    26     0.595694         0.471715    0.928604   0.840495      0.013972   
    27     0.810157         0.564629    0.972250   0.914754      0.006191   
    28     0.983090         0.779044    0.967960   0.995811      0.017644   
    29     0.984387         0.871958    0.965980   0.960108      0.021406   
    30     0.992174         0.843369    0.959544   0.875917      0.009597   
    31     0.911061         0.678984    0.965567   0.805024      0.041961   
    32     0.606076         0.185827    0.902862   0.754283      0.015316   
    33     0.465589         0.407390    1.000000   0.688969      0.051133   
    
        Brand_Equity       ...         pct_PromoMarketDollars_Category  \
    0       0.954106       ...                                0.486112   
    1       0.954106       ...                                0.560678   
    2       0.954106       ...                                0.326943   
    3       0.979608       ...                                0.210792   
    4       0.985152       ...                                0.314037   
    5       0.985152       ...                                0.153434   
    6       0.990037       ...                                0.109698   
    7       0.993701       ...                                0.433056   
    8       0.993701       ...                                0.435924   
    9       0.994536       ...                                0.080445   
    10      0.996625       ...                                0.029826   
    11      0.996625       ...                                0.072845   
    12      0.996625       ...                                0.065962   
    13      1.000000       ...                                0.714112   
    14      1.000000       ...                                0.387169   
    15      0.989394       ...                                0.623772   
    16      0.986502       ...                                0.411546   
    17      0.980717       ...                                0.560678   
    18      0.975703       ...                                0.543470   
    19      0.975703       ...                                0.470339   
    20      0.977053       ...                                0.142966   
    21      0.981102       ...                                0.004847   
    22      0.981102       ...                                0.003413   
    23      0.981102       ...                                0.018785   
    24      0.962430       ...                                0.989432   
    25      0.962430       ...                                1.000000   
    26      0.954837       ...                                0.166339   
    27      0.952306       ...                                0.404376   
    28      0.958493       ...                                0.476074   
    29      0.964679       ...                                0.283924   
    30      0.964679       ...                                0.023947   
    31      0.961112       ...                                0.031260   
    32      0.948031       ...                                0.364226   
    33      0.948031       ...                                0.240905   
    
        RPI_Category  Competitor1_RPI  Competitor2_RPI  Competitor3_RPI  \
    0       0.817283         0.797459         0.645420         0.877539   
    1       0.830336         0.803018         0.675655         0.901543   
    2       0.835148         0.791094         0.740592         0.824697   
    3       0.871700         0.811929         0.663912         0.819875   
    4       0.881899         0.824841         0.654035         0.840067   
    5       0.896894         0.818986         0.671541         0.886221   
    6       0.904833         0.829652         0.677311         0.854974   
    7       0.874454         0.776784         0.617393         0.815504   
    8       0.869626         0.789791         0.678462         0.800129   
    9       0.903507         0.861948         0.845837         0.880077   
    10      0.936027         0.914512         0.641253         0.908150   
    11      0.906906         0.882219         0.715435         0.880589   
    12      0.890626         0.865032         0.740104         0.879110   
    13      0.853246         0.838298         0.652631         0.842714   
    14      0.900967         0.883892         0.705954         0.883876   
    15      0.846038         0.816973         0.647337         0.810407   
    16      0.868731         0.851029         0.608038         0.824682   
    17      0.891605         0.839166         0.707355         0.873120   
    18      0.894705         0.850123         0.642263         0.887728   
    19      0.911212         0.852214         0.682360         0.896103   
    20      0.961870         0.950238         0.744196         0.956657   
    21      0.999785         0.978489         0.900278         0.990933   
    22      0.991826         0.999401         0.858970         0.948670   
    23      1.000000         1.000000         1.000000         1.000000   
    24      0.900374         0.910313         0.763536         0.998374   
    25      0.741222         0.735717         0.611053         0.827024   
    26      0.854347         0.826316         0.688734         0.937875   
    27      0.829099         0.796124         0.655732         0.883543   
    28      0.772993         0.688395         0.587546         0.760173   
    29      0.812375         0.716965         0.621340         0.821710   
    30      0.908023         0.827465         0.715191         0.899186   
    31      0.864499         0.823874         0.794937         0.926473   
    32      0.802291         0.774279         0.660671         0.845786   
    33      0.802234         0.774285         0.728152         0.810782   
    
        Competitor4_RPI  EQ_Category  EQ_Subcategory  \
    0          0.845470     0.606548        0.391803   
    1          0.836858     0.667074        0.394971   
    2          0.828303     0.714652        0.456985   
    3          0.845431     0.741744        0.569525   
    4          0.844332     0.843015        0.743440   
    5          0.912687     0.981541        0.951482   
    6          0.872732     1.000000        0.978278   
    7          0.860167     0.987347        0.931456   
    8          0.843962     0.856949        0.716090   
    9          0.894332     0.707956        0.497102   
    10         0.929255     0.677465        0.412919   
    11         0.900936     0.616496        0.350824   
    12         0.871451     0.571478        0.318059   
    13         0.853377     0.663919        0.429087   
    14         0.914446     0.703285        0.452358   
    15         0.828820     0.753870        0.542925   
    16         0.826598     0.833394        0.761914   
    17         0.886675     0.957016        0.943906   
    18         0.904485     0.914845        0.880930   
    19         0.889293     0.795387        0.671865   
    20         1.000000     0.700949        0.502059   
    21         0.978537     0.660663        0.405318   
    22         0.983890     0.584970        0.333968   
    23         0.965407     0.565125        0.304842   
    24         0.890786     0.628646        0.401981   
    25         0.768179     0.673592        0.453571   
    26         0.852407     0.705502        0.552632   
    27         0.787301     0.786923        0.717232   
    28         0.770264     0.964085        1.000000   
    29         0.810182     0.875425        0.848289   
    30         0.926214     0.782262        0.682073   
    31         0.898286     0.651298        0.489807   
    32         0.798248     0.549317        0.321089   
    33         0.782488     0.527922        0.294197   
    
        pct_PromoMarketDollars_Subcategory  RPI_Subcategory  
    0                             0.410278         0.855236  
    1                             0.584034         0.844392  
    2                             0.316142         0.852084  
    3                             0.142708         0.890083  
    4                             0.164026         0.913959  
    5                             0.075415         0.929353  
    6                             0.054933         0.950378  
    7                             0.235195         0.906135  
    8                             0.253884         0.901628  
    9                             0.063712         0.926196  
    10                            0.028844         0.939203  
    11                            0.089475         0.915480  
    12                            0.089904         0.901968  
    13                            0.700864         0.873500  
    14                            0.371424         0.913279  
    15                            0.499148         0.850562  
    16                            0.196652         0.908874  
    17                            0.273272         0.922920  
    18                            0.271646         0.932008  
    19                            0.272094         0.949731  
    20                            0.122477         0.973182  
    21                            0.004857         1.000000  
    22                            0.004182         0.995857  
    23                            0.029343         0.985784  
    24                            1.000000         0.904735  
    25                            0.828962         0.748125  
    26                            0.119203         0.860216  
    27                            0.200952         0.835603  
    28                            0.220312         0.786582  
    29                            0.147332         0.823096  
    30                            0.014181         0.915401  
    31                            0.024970         0.864369  
    32                            0.414872         0.791857  
    33                            0.351059         0.786430  
    
    [34 rows x 26 columns]
    

### Train Test Split & Standizing x variable/regressor variable


```python
x_train,x_test,y_train,y_test=train_test_split(x_data,y_data,test_size=0.20,random_state=0)
```


```python
sc = StandardScaler()
x_train = sc.fit_transform(x_train)
x_test = sc.transform(x_test)
```

### Fitting Random Forest Regressor Model


```python
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
```


```python
m=[]
rmse_test=[]
n=range(4,500)
for n in n:
    regressor=RandomForestRegressor(n_estimators=n,min_samples_leaf=1,n_jobs=-1,oob_score=True,random_state=0)
    regressor.fit(x_train,y_train)
    y_pred_test=regressor.predict(x_test)
    m.append(n)
    rmse_test.append(np.sqrt(metrics.mean_squared_error(y_test,y_pred_test)))
```

    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    


```python
m=pd.DataFrame(m)
rmse_test=pd.DataFrame(rmse_test)
f_results=pd.concat([m,rmse_test], axis=1, ignore_index=True)
f_results.columns=['Number of Estimators','Root Mean Square Error Testing']
```


```python
f_results.sort_values(by='Root Mean Square Error Testing', ascending=True).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Number of Estimators</th>
      <th>Root Mean Square Error Testing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>10</th>
      <td>14</td>
      <td>17.481330</td>
    </tr>
    <tr>
      <th>13</th>
      <td>17</td>
      <td>17.589577</td>
    </tr>
    <tr>
      <th>86</th>
      <td>90</td>
      <td>17.729917</td>
    </tr>
    <tr>
      <th>66</th>
      <td>70</td>
      <td>17.736798</td>
    </tr>
    <tr>
      <th>87</th>
      <td>91</td>
      <td>17.765746</td>
    </tr>
  </tbody>
</table>
</div>



### Feature Importance of the variables


```python
feat_importances = pd.Series(regressor.feature_importances_, index=x_data.columns)
feat_importances.nlargest(15).plot(kind='barh')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1ea44c78fd0>




![png](output_32_1.png)



```python
feat_importances.nlargest(15)
```




    Inflation                          0.317090
    Est_ACV_Selling                    0.184234
    pct_ACV                            0.177660
    Fuel_Price                         0.076064
    Avg_no_of_Items                    0.063875
    pct_PromoMarketDollars_Category    0.033747
    EQ_Base_Price                      0.021380
    EQ_Category                        0.018908
    Competitor1_RPI                    0.013664
    Competitor2_RPI                    0.012801
    Any_Promo_pct_ACV                  0.012405
    SOS_pct                            0.011809
    EQ_Subcategory                     0.011473
    Trade_Invest                       0.008373
    Avg_EQ_Price                       0.005561
    dtype: float64



### Correlation Matrix for x variables / regressor variables


```python
x_data.corr()[1:13].T

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Print_Working_Cost.Ads50</th>
      <th>SOS_pct</th>
      <th>CCFOT</th>
      <th>Median_Temp</th>
      <th>Median_Rainfall</th>
      <th>Fuel_Price</th>
      <th>Inflation</th>
      <th>Trade_Invest</th>
      <th>Brand_Equity</th>
      <th>Avg_EQ_Price</th>
      <th>Any_Promo_pct_ACV</th>
      <th>EQ_Base_Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Print_Impressions.Ads40</th>
      <td>0.885577</td>
      <td>0.029569</td>
      <td>-0.041813</td>
      <td>0.456273</td>
      <td>0.615080</td>
      <td>0.345791</td>
      <td>0.365865</td>
      <td>-0.389682</td>
      <td>-0.144080</td>
      <td>-0.239130</td>
      <td>-0.122228</td>
      <td>-0.001797</td>
    </tr>
    <tr>
      <th>Print_Working_Cost.Ads50</th>
      <td>1.000000</td>
      <td>0.023169</td>
      <td>-0.028270</td>
      <td>0.413013</td>
      <td>0.578525</td>
      <td>0.189840</td>
      <td>0.239799</td>
      <td>-0.411186</td>
      <td>-0.033238</td>
      <td>-0.187004</td>
      <td>-0.048389</td>
      <td>0.218488</td>
    </tr>
    <tr>
      <th>SOS_pct</th>
      <td>0.023169</td>
      <td>1.000000</td>
      <td>-0.345078</td>
      <td>0.033264</td>
      <td>0.006132</td>
      <td>0.192774</td>
      <td>-0.068115</td>
      <td>-0.028801</td>
      <td>-0.133445</td>
      <td>0.078455</td>
      <td>0.000841</td>
      <td>0.002683</td>
    </tr>
    <tr>
      <th>CCFOT</th>
      <td>-0.028270</td>
      <td>-0.345078</td>
      <td>1.000000</td>
      <td>0.105169</td>
      <td>-0.070668</td>
      <td>-0.440675</td>
      <td>-0.183333</td>
      <td>0.285497</td>
      <td>0.459858</td>
      <td>0.115414</td>
      <td>-0.371729</td>
      <td>0.111847</td>
    </tr>
    <tr>
      <th>Median_Temp</th>
      <td>0.413013</td>
      <td>0.033264</td>
      <td>0.105169</td>
      <td>1.000000</td>
      <td>0.424312</td>
      <td>0.212518</td>
      <td>-0.083105</td>
      <td>-0.001996</td>
      <td>0.194645</td>
      <td>-0.153707</td>
      <td>-0.027724</td>
      <td>-0.040056</td>
    </tr>
    <tr>
      <th>Median_Rainfall</th>
      <td>0.578525</td>
      <td>0.006132</td>
      <td>-0.070668</td>
      <td>0.424312</td>
      <td>1.000000</td>
      <td>0.054078</td>
      <td>-0.056557</td>
      <td>-0.021381</td>
      <td>-0.039944</td>
      <td>-0.386004</td>
      <td>0.225432</td>
      <td>-0.171430</td>
    </tr>
    <tr>
      <th>Fuel_Price</th>
      <td>0.189840</td>
      <td>0.192774</td>
      <td>-0.440675</td>
      <td>0.212518</td>
      <td>0.054078</td>
      <td>1.000000</td>
      <td>0.756511</td>
      <td>-0.679715</td>
      <td>-0.372351</td>
      <td>0.077900</td>
      <td>-0.110730</td>
      <td>0.101325</td>
    </tr>
    <tr>
      <th>Inflation</th>
      <td>0.239799</td>
      <td>-0.068115</td>
      <td>-0.183333</td>
      <td>-0.083105</td>
      <td>-0.056557</td>
      <td>0.756511</td>
      <td>1.000000</td>
      <td>-0.775554</td>
      <td>-0.220669</td>
      <td>0.116433</td>
      <td>-0.094475</td>
      <td>0.294171</td>
    </tr>
    <tr>
      <th>Trade_Invest</th>
      <td>-0.411186</td>
      <td>-0.028801</td>
      <td>0.285497</td>
      <td>-0.001996</td>
      <td>-0.021381</td>
      <td>-0.679715</td>
      <td>-0.775554</td>
      <td>1.000000</td>
      <td>0.294169</td>
      <td>-0.170858</td>
      <td>0.055983</td>
      <td>-0.442853</td>
    </tr>
    <tr>
      <th>Brand_Equity</th>
      <td>-0.033238</td>
      <td>-0.133445</td>
      <td>0.459858</td>
      <td>0.194645</td>
      <td>-0.039944</td>
      <td>-0.372351</td>
      <td>-0.220669</td>
      <td>0.294169</td>
      <td>1.000000</td>
      <td>0.344549</td>
      <td>-0.122353</td>
      <td>0.384126</td>
    </tr>
    <tr>
      <th>Avg_EQ_Price</th>
      <td>-0.187004</td>
      <td>0.078455</td>
      <td>0.115414</td>
      <td>-0.153707</td>
      <td>-0.386004</td>
      <td>0.077900</td>
      <td>0.116433</td>
      <td>-0.170858</td>
      <td>0.344549</td>
      <td>1.000000</td>
      <td>-0.602988</td>
      <td>0.762509</td>
    </tr>
    <tr>
      <th>Any_Promo_pct_ACV</th>
      <td>-0.048389</td>
      <td>0.000841</td>
      <td>-0.371729</td>
      <td>-0.027724</td>
      <td>0.225432</td>
      <td>-0.110730</td>
      <td>-0.094475</td>
      <td>0.055983</td>
      <td>-0.122353</td>
      <td>-0.602988</td>
      <td>1.000000</td>
      <td>-0.309623</td>
    </tr>
    <tr>
      <th>EQ_Base_Price</th>
      <td>0.218488</td>
      <td>0.002683</td>
      <td>0.111847</td>
      <td>-0.040056</td>
      <td>-0.171430</td>
      <td>0.101325</td>
      <td>0.294171</td>
      <td>-0.442853</td>
      <td>0.384126</td>
      <td>0.762509</td>
      <td>-0.309623</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>Est_ACV_Selling</th>
      <td>-0.327422</td>
      <td>-0.218720</td>
      <td>0.404321</td>
      <td>-0.071944</td>
      <td>-0.027484</td>
      <td>-0.907527</td>
      <td>-0.795595</td>
      <td>0.796502</td>
      <td>0.536070</td>
      <td>-0.065746</td>
      <td>0.187299</td>
      <td>-0.171862</td>
    </tr>
    <tr>
      <th>pct_ACV</th>
      <td>-0.296768</td>
      <td>-0.176664</td>
      <td>0.371885</td>
      <td>-0.028794</td>
      <td>-0.003774</td>
      <td>-0.897644</td>
      <td>-0.820046</td>
      <td>0.793968</td>
      <td>0.523187</td>
      <td>-0.045140</td>
      <td>0.178360</td>
      <td>-0.157476</td>
    </tr>
    <tr>
      <th>Avg_no_of_Items</th>
      <td>0.028772</td>
      <td>0.131848</td>
      <td>0.148364</td>
      <td>0.284871</td>
      <td>0.196933</td>
      <td>-0.425945</td>
      <td>-0.405009</td>
      <td>0.310979</td>
      <td>0.086835</td>
      <td>-0.267906</td>
      <td>0.402054</td>
      <td>-0.153121</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Category</th>
      <td>0.180125</td>
      <td>-0.111153</td>
      <td>-0.271230</td>
      <td>-0.185558</td>
      <td>0.246431</td>
      <td>-0.095525</td>
      <td>0.138689</td>
      <td>-0.188994</td>
      <td>-0.198729</td>
      <td>-0.510992</td>
      <td>0.808399</td>
      <td>-0.006323</td>
    </tr>
    <tr>
      <th>RPI_Category</th>
      <td>-0.097858</td>
      <td>0.071753</td>
      <td>0.230504</td>
      <td>0.106291</td>
      <td>-0.222050</td>
      <td>-0.088669</td>
      <td>-0.122397</td>
      <td>0.021665</td>
      <td>0.527441</td>
      <td>0.917140</td>
      <td>-0.570607</td>
      <td>0.719538</td>
    </tr>
    <tr>
      <th>Competitor1_RPI</th>
      <td>-0.163087</td>
      <td>0.042714</td>
      <td>0.162546</td>
      <td>-0.213735</td>
      <td>-0.388982</td>
      <td>-0.070388</td>
      <td>0.018642</td>
      <td>-0.086529</td>
      <td>0.416680</td>
      <td>0.969570</td>
      <td>-0.532731</td>
      <td>0.808854</td>
    </tr>
    <tr>
      <th>Competitor2_RPI</th>
      <td>-0.256427</td>
      <td>0.289360</td>
      <td>0.060614</td>
      <td>-0.224939</td>
      <td>-0.286669</td>
      <td>0.085454</td>
      <td>0.048595</td>
      <td>-0.169247</td>
      <td>0.091844</td>
      <td>0.814798</td>
      <td>-0.604854</td>
      <td>0.527514</td>
    </tr>
    <tr>
      <th>Competitor3_RPI</th>
      <td>-0.217307</td>
      <td>0.025595</td>
      <td>-0.096051</td>
      <td>-0.219076</td>
      <td>-0.322546</td>
      <td>0.125857</td>
      <td>0.161397</td>
      <td>-0.202738</td>
      <td>-0.008592</td>
      <td>0.838324</td>
      <td>-0.381850</td>
      <td>0.616343</td>
    </tr>
    <tr>
      <th>Competitor4_RPI</th>
      <td>-0.091658</td>
      <td>-0.029154</td>
      <td>0.280148</td>
      <td>0.107923</td>
      <td>-0.274323</td>
      <td>-0.063239</td>
      <td>-0.053173</td>
      <td>-0.029911</td>
      <td>0.441804</td>
      <td>0.906791</td>
      <td>-0.546226</td>
      <td>0.704712</td>
    </tr>
    <tr>
      <th>EQ_Category</th>
      <td>0.410616</td>
      <td>-0.088722</td>
      <td>0.111316</td>
      <td>0.787306</td>
      <td>0.580794</td>
      <td>-0.059617</td>
      <td>-0.282238</td>
      <td>0.140015</td>
      <td>0.215215</td>
      <td>-0.428594</td>
      <td>0.343056</td>
      <td>-0.184038</td>
    </tr>
    <tr>
      <th>EQ_Subcategory</th>
      <td>0.467771</td>
      <td>-0.043855</td>
      <td>0.030949</td>
      <td>0.797528</td>
      <td>0.599704</td>
      <td>0.071566</td>
      <td>-0.184164</td>
      <td>0.054190</td>
      <td>0.112376</td>
      <td>-0.454929</td>
      <td>0.327304</td>
      <td>-0.207878</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Subcategory</th>
      <td>-0.048446</td>
      <td>-0.040242</td>
      <td>-0.358731</td>
      <td>-0.452935</td>
      <td>0.031959</td>
      <td>-0.106954</td>
      <td>0.163150</td>
      <td>-0.167674</td>
      <td>-0.251832</td>
      <td>-0.361196</td>
      <td>0.739626</td>
      <td>-0.017487</td>
    </tr>
    <tr>
      <th>RPI_Subcategory</th>
      <td>-0.027150</td>
      <td>0.012690</td>
      <td>0.277197</td>
      <td>0.218132</td>
      <td>-0.115129</td>
      <td>-0.216612</td>
      <td>-0.252138</td>
      <td>0.125304</td>
      <td>0.602656</td>
      <td>0.806916</td>
      <td>-0.458516</td>
      <td>0.674421</td>
    </tr>
  </tbody>
</table>
</div>




```python
x_data.corr()[14:26].T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pct_ACV</th>
      <th>Avg_no_of_Items</th>
      <th>pct_PromoMarketDollars_Category</th>
      <th>RPI_Category</th>
      <th>Competitor1_RPI</th>
      <th>Competitor2_RPI</th>
      <th>Competitor3_RPI</th>
      <th>Competitor4_RPI</th>
      <th>EQ_Category</th>
      <th>EQ_Subcategory</th>
      <th>pct_PromoMarketDollars_Subcategory</th>
      <th>RPI_Subcategory</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Print_Impressions.Ads40</th>
      <td>-0.410766</td>
      <td>-0.021475</td>
      <td>0.045208</td>
      <td>-0.179180</td>
      <td>-0.296648</td>
      <td>-0.251578</td>
      <td>-0.242524</td>
      <td>-0.133339</td>
      <td>0.367282</td>
      <td>0.441200</td>
      <td>-0.124582</td>
      <td>-0.148486</td>
    </tr>
    <tr>
      <th>Print_Working_Cost.Ads50</th>
      <td>-0.296768</td>
      <td>0.028772</td>
      <td>0.180125</td>
      <td>-0.097858</td>
      <td>-0.163087</td>
      <td>-0.256427</td>
      <td>-0.217307</td>
      <td>-0.091658</td>
      <td>0.410616</td>
      <td>0.467771</td>
      <td>-0.048446</td>
      <td>-0.027150</td>
    </tr>
    <tr>
      <th>SOS_pct</th>
      <td>-0.176664</td>
      <td>0.131848</td>
      <td>-0.111153</td>
      <td>0.071753</td>
      <td>0.042714</td>
      <td>0.289360</td>
      <td>0.025595</td>
      <td>-0.029154</td>
      <td>-0.088722</td>
      <td>-0.043855</td>
      <td>-0.040242</td>
      <td>0.012690</td>
    </tr>
    <tr>
      <th>CCFOT</th>
      <td>0.371885</td>
      <td>0.148364</td>
      <td>-0.271230</td>
      <td>0.230504</td>
      <td>0.162546</td>
      <td>0.060614</td>
      <td>-0.096051</td>
      <td>0.280148</td>
      <td>0.111316</td>
      <td>0.030949</td>
      <td>-0.358731</td>
      <td>0.277197</td>
    </tr>
    <tr>
      <th>Median_Temp</th>
      <td>-0.028794</td>
      <td>0.284871</td>
      <td>-0.185558</td>
      <td>0.106291</td>
      <td>-0.213735</td>
      <td>-0.224939</td>
      <td>-0.219076</td>
      <td>0.107923</td>
      <td>0.787306</td>
      <td>0.797528</td>
      <td>-0.452935</td>
      <td>0.218132</td>
    </tr>
    <tr>
      <th>Median_Rainfall</th>
      <td>-0.003774</td>
      <td>0.196933</td>
      <td>0.246431</td>
      <td>-0.222050</td>
      <td>-0.388982</td>
      <td>-0.286669</td>
      <td>-0.322546</td>
      <td>-0.274323</td>
      <td>0.580794</td>
      <td>0.599704</td>
      <td>0.031959</td>
      <td>-0.115129</td>
    </tr>
    <tr>
      <th>Fuel_Price</th>
      <td>-0.897644</td>
      <td>-0.425945</td>
      <td>-0.095525</td>
      <td>-0.088669</td>
      <td>-0.070388</td>
      <td>0.085454</td>
      <td>0.125857</td>
      <td>-0.063239</td>
      <td>-0.059617</td>
      <td>0.071566</td>
      <td>-0.106954</td>
      <td>-0.216612</td>
    </tr>
    <tr>
      <th>Inflation</th>
      <td>-0.820046</td>
      <td>-0.405009</td>
      <td>0.138689</td>
      <td>-0.122397</td>
      <td>0.018642</td>
      <td>0.048595</td>
      <td>0.161397</td>
      <td>-0.053173</td>
      <td>-0.282238</td>
      <td>-0.184164</td>
      <td>0.163150</td>
      <td>-0.252138</td>
    </tr>
    <tr>
      <th>Trade_Invest</th>
      <td>0.793968</td>
      <td>0.310979</td>
      <td>-0.188994</td>
      <td>0.021665</td>
      <td>-0.086529</td>
      <td>-0.169247</td>
      <td>-0.202738</td>
      <td>-0.029911</td>
      <td>0.140015</td>
      <td>0.054190</td>
      <td>-0.167674</td>
      <td>0.125304</td>
    </tr>
    <tr>
      <th>Brand_Equity</th>
      <td>0.523187</td>
      <td>0.086835</td>
      <td>-0.198729</td>
      <td>0.527441</td>
      <td>0.416680</td>
      <td>0.091844</td>
      <td>-0.008592</td>
      <td>0.441804</td>
      <td>0.215215</td>
      <td>0.112376</td>
      <td>-0.251832</td>
      <td>0.602656</td>
    </tr>
    <tr>
      <th>Avg_EQ_Price</th>
      <td>-0.045140</td>
      <td>-0.267906</td>
      <td>-0.510992</td>
      <td>0.917140</td>
      <td>0.969570</td>
      <td>0.814798</td>
      <td>0.838324</td>
      <td>0.906791</td>
      <td>-0.428594</td>
      <td>-0.454929</td>
      <td>-0.361196</td>
      <td>0.806916</td>
    </tr>
    <tr>
      <th>Any_Promo_pct_ACV</th>
      <td>0.178360</td>
      <td>0.402054</td>
      <td>0.808399</td>
      <td>-0.570607</td>
      <td>-0.532731</td>
      <td>-0.604854</td>
      <td>-0.381850</td>
      <td>-0.546226</td>
      <td>0.343056</td>
      <td>0.327304</td>
      <td>0.739626</td>
      <td>-0.458516</td>
    </tr>
    <tr>
      <th>EQ_Base_Price</th>
      <td>-0.157476</td>
      <td>-0.153121</td>
      <td>-0.006323</td>
      <td>0.719538</td>
      <td>0.808854</td>
      <td>0.527514</td>
      <td>0.616343</td>
      <td>0.704712</td>
      <td>-0.184038</td>
      <td>-0.207878</td>
      <td>-0.017487</td>
      <td>0.674421</td>
    </tr>
    <tr>
      <th>Est_ACV_Selling</th>
      <td>0.991252</td>
      <td>0.434146</td>
      <td>-0.001941</td>
      <td>0.146433</td>
      <td>0.061837</td>
      <td>-0.141503</td>
      <td>-0.176610</td>
      <td>0.103909</td>
      <td>0.207785</td>
      <td>0.074010</td>
      <td>0.002243</td>
      <td>0.298207</td>
    </tr>
    <tr>
      <th>pct_ACV</th>
      <td>1.000000</td>
      <td>0.456081</td>
      <td>-0.030391</td>
      <td>0.185930</td>
      <td>0.078384</td>
      <td>-0.130371</td>
      <td>-0.156016</td>
      <td>0.138410</td>
      <td>0.245077</td>
      <td>0.117590</td>
      <td>-0.035681</td>
      <td>0.343893</td>
    </tr>
    <tr>
      <th>Avg_no_of_Items</th>
      <td>0.456081</td>
      <td>1.000000</td>
      <td>0.255857</td>
      <td>-0.109382</td>
      <td>-0.211863</td>
      <td>-0.231681</td>
      <td>-0.268367</td>
      <td>-0.104429</td>
      <td>0.367835</td>
      <td>0.307489</td>
      <td>0.150799</td>
      <td>0.010883</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Category</th>
      <td>-0.030391</td>
      <td>0.255857</td>
      <td>1.000000</td>
      <td>-0.559384</td>
      <td>-0.410181</td>
      <td>-0.492881</td>
      <td>-0.292004</td>
      <td>-0.521537</td>
      <td>0.132378</td>
      <td>0.119078</td>
      <td>0.920912</td>
      <td>-0.489812</td>
    </tr>
    <tr>
      <th>RPI_Category</th>
      <td>0.185930</td>
      <td>-0.109382</td>
      <td>-0.559384</td>
      <td>1.000000</td>
      <td>0.920631</td>
      <td>0.692990</td>
      <td>0.716792</td>
      <td>0.938083</td>
      <td>-0.096641</td>
      <td>-0.147258</td>
      <td>-0.511103</td>
      <td>0.965653</td>
    </tr>
    <tr>
      <th>Competitor1_RPI</th>
      <td>0.078384</td>
      <td>-0.211863</td>
      <td>-0.410181</td>
      <td>0.920631</td>
      <td>1.000000</td>
      <td>0.743752</td>
      <td>0.814050</td>
      <td>0.881728</td>
      <td>-0.391342</td>
      <td>-0.435111</td>
      <td>-0.286405</td>
      <td>0.841556</td>
    </tr>
    <tr>
      <th>Competitor2_RPI</th>
      <td>-0.130371</td>
      <td>-0.231681</td>
      <td>-0.492881</td>
      <td>0.692990</td>
      <td>0.743752</td>
      <td>1.000000</td>
      <td>0.715567</td>
      <td>0.658883</td>
      <td>-0.489172</td>
      <td>-0.497655</td>
      <td>-0.320972</td>
      <td>0.556034</td>
    </tr>
    <tr>
      <th>Competitor3_RPI</th>
      <td>-0.156016</td>
      <td>-0.268367</td>
      <td>-0.292004</td>
      <td>0.716792</td>
      <td>0.814050</td>
      <td>0.715567</td>
      <td>1.000000</td>
      <td>0.769610</td>
      <td>-0.414149</td>
      <td>-0.413131</td>
      <td>-0.143599</td>
      <td>0.612924</td>
    </tr>
    <tr>
      <th>Competitor4_RPI</th>
      <td>0.138410</td>
      <td>-0.104429</td>
      <td>-0.521537</td>
      <td>0.938083</td>
      <td>0.881728</td>
      <td>0.658883</td>
      <td>0.769610</td>
      <td>1.000000</td>
      <td>-0.141357</td>
      <td>-0.190895</td>
      <td>-0.446442</td>
      <td>0.897553</td>
    </tr>
    <tr>
      <th>EQ_Category</th>
      <td>0.245077</td>
      <td>0.367835</td>
      <td>0.132378</td>
      <td>-0.096641</td>
      <td>-0.391342</td>
      <td>-0.489172</td>
      <td>-0.414149</td>
      <td>-0.141357</td>
      <td>1.000000</td>
      <td>0.982777</td>
      <td>-0.182173</td>
      <td>0.088412</td>
    </tr>
    <tr>
      <th>EQ_Subcategory</th>
      <td>0.117590</td>
      <td>0.307489</td>
      <td>0.119078</td>
      <td>-0.147258</td>
      <td>-0.435111</td>
      <td>-0.497655</td>
      <td>-0.413131</td>
      <td>-0.190895</td>
      <td>0.982777</td>
      <td>1.000000</td>
      <td>-0.205225</td>
      <td>0.028393</td>
    </tr>
    <tr>
      <th>pct_PromoMarketDollars_Subcategory</th>
      <td>-0.035681</td>
      <td>0.150799</td>
      <td>0.920912</td>
      <td>-0.511103</td>
      <td>-0.286405</td>
      <td>-0.320972</td>
      <td>-0.143599</td>
      <td>-0.446442</td>
      <td>-0.182173</td>
      <td>-0.205225</td>
      <td>1.000000</td>
      <td>-0.505861</td>
    </tr>
    <tr>
      <th>RPI_Subcategory</th>
      <td>0.343893</td>
      <td>0.010883</td>
      <td>-0.489812</td>
      <td>0.965653</td>
      <td>0.841556</td>
      <td>0.556034</td>
      <td>0.612924</td>
      <td>0.897553</td>
      <td>0.088412</td>
      <td>0.028393</td>
      <td>-0.505861</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



### After Checking Variable Importance and Correlation Matrix we select the following list of regressor variables


```python
x_data_new=x_data[['Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price']]
```


```python
x_train_new,x_test_new,y_train_new,y_test_new=train_test_split(x_data_new,y_data,test_size=0.20,random_state=0)
```


```python
x_train_new = sc.fit_transform(x_train_new)
x_test_new = sc.transform(x_test_new)
```


```python
m_new=[]
rmse_test_new=[]
n_new=range(4,500)
for n in n_new:
    regressor=RandomForestRegressor(n_estimators=n,min_samples_leaf=1,n_jobs=-1,oob_score=True,random_state=0)
    regressor.fit(x_train_new,y_train_new)
    y_pred_test_new=regressor.predict(x_test_new)
    m_new.append(n)
    rmse_test_new.append(np.sqrt(metrics.mean_squared_error(y_test_new,y_pred_test_new)))
```

    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:724: UserWarning: Some inputs do not have OOB scores. This probably means too few trees were used to compute any reliable oob estimates.
      warn("Some inputs do not have OOB scores. "
    


```python
m_new=pd.DataFrame(m_new)
rmse_test_new=pd.DataFrame(rmse_test_new)
f_results_new=pd.concat([m_new,rmse_test_new], axis=1, ignore_index=True)
f_results_new.columns=['Number of Trees','Root Mean Square Error Testing']
```


```python
f_results_new.sort_values(by='Root Mean Square Error Testing', ascending=True).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Number of Trees</th>
      <th>Root Mean Square Error Testing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>139</th>
      <td>143</td>
      <td>19.739109</td>
    </tr>
    <tr>
      <th>138</th>
      <td>142</td>
      <td>19.765413</td>
    </tr>
    <tr>
      <th>141</th>
      <td>145</td>
      <td>19.770613</td>
    </tr>
    <tr>
      <th>133</th>
      <td>137</td>
      <td>19.779478</td>
    </tr>
    <tr>
      <th>134</th>
      <td>138</td>
      <td>19.812563</td>
    </tr>
  </tbody>
</table>
</div>



## Testing Data Set


```python
test_data=pd.read_csv('TestData - Test.csv')
```


```python
[col for col in test_data.columns if test_data[col].isnull().any()]
```




    ['Digital_Impressions',
     'Digital_Working_cost',
     'OOH_Impressions',
     'OOH_Working_Cost',
     'Digital_Impressions_pct',
     'Any_Feat_pct_ACV',
     'Any_Disp_pct_ACV',
     'Magazine_Impressions_pct',
     'TV_GRP']




```python
test_data=test_data.drop(['Period','Social_Search_Impressions',
 'Social_Search_Working_cost',
 'Digital_Impressions',
 'Digital_Working_cost',
 'Print_Impressions.Ads40',
 'Print_Working_Cost.Ads50',
 'OOH_Impressions',
 'OOH_Working_Cost',
 'Digital_Impressions_pct',
 'Any_Feat_pct_ACV',
 'Any_Disp_pct_ACV',
 'Magazine_Impressions_pct',
 'TV_GRP'],axis=1)
```


```python
x_validation=test_data[['Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price']]
y_validation_actual=test_data['EQ']
```


```python
x_validation = x_validation.div(x_validation.quantile(.99)).clip_upper(1)
```


```python
x_validation = sc.transform(x_validation)
```


```python
regressor=RandomForestRegressor(n_estimators=143,min_samples_leaf=1,n_jobs=-1,oob_score=True,random_state=0)
regressor.fit(x_train_new,y_train_new)
y_pred_validation=regressor.predict(x_validation)
```


```python
print("Root Mean Squared Error is:",np.sqrt(metrics.mean_squared_error(y_validation_actual,y_pred_validation)))
```

    Root Mean Squared Error is: 26.377887804950475
    

#### Comment : The root mean square error of the validation set is 26.378 which is really good.

## Let's move on to Time Series Forecasting Model


```python
data.shape
```




    (34, 39)




```python
data_xreg1= pd.DataFrame(data=data, columns=['Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price'])
data_xreg2=pd.DataFrame(data=test_data,columns=['Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price'])

data_xreg_Final=data_xreg1.append(data_xreg2)
```


```python
data_xreg_Final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Inflation</th>
      <th>Est_ACV_Selling</th>
      <th>pct_ACV</th>
      <th>Fuel_Price</th>
      <th>Avg_no_of_Items</th>
      <th>pct_PromoMarketDollars_Category</th>
      <th>EQ_Base_Price</th>
      <th>EQ_Category</th>
      <th>Competitor1_RPI</th>
      <th>Competitor2_RPI</th>
      <th>Any_Promo_pct_ACV</th>
      <th>SOS_pct</th>
      <th>EQ_Subcategory</th>
      <th>Trade_Invest</th>
      <th>Avg_EQ_Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.013258</td>
      <td>8696587915</td>
      <td>39.441025</td>
      <td>8.226</td>
      <td>2.611782</td>
      <td>0.0339</td>
      <td>1.427532</td>
      <td>1728388.673</td>
      <td>97.173365</td>
      <td>35.557371</td>
      <td>9.691794</td>
      <td>7.446883</td>
      <td>331927.5394</td>
      <td>42744.25684</td>
      <td>49.091447</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.009938</td>
      <td>8682307085</td>
      <td>38.417224</td>
      <td>7.473</td>
      <td>2.522814</td>
      <td>0.0391</td>
      <td>1.442716</td>
      <td>1900859.879</td>
      <td>97.850760</td>
      <td>37.223072</td>
      <td>9.415938</td>
      <td>11.677082</td>
      <td>334611.3806</td>
      <td>36290.43956</td>
      <td>49.057612</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.007832</td>
      <td>8706897549</td>
      <td>36.499442</td>
      <td>8.001</td>
      <td>2.477322</td>
      <td>0.0228</td>
      <td>1.423408</td>
      <td>2036436.906</td>
      <td>96.397739</td>
      <td>40.800563</td>
      <td>5.176684</td>
      <td>0.102858</td>
      <td>387148.3582</td>
      <td>34852.14166</td>
      <td>49.367514</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.010034</td>
      <td>8660288592</td>
      <td>38.135159</td>
      <td>8.767</td>
      <td>2.520409</td>
      <td>0.0147</td>
      <td>1.443401</td>
      <td>2113635.013</td>
      <td>98.936519</td>
      <td>36.576140</td>
      <td>6.088273</td>
      <td>0.249055</td>
      <td>482489.6740</td>
      <td>24869.55899</td>
      <td>50.657634</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.009546</td>
      <td>8644518558</td>
      <td>38.629564</td>
      <td>9.277</td>
      <td>2.497285</td>
      <td>0.0219</td>
      <td>1.473687</td>
      <td>2402211.102</td>
      <td>100.509969</td>
      <td>36.032016</td>
      <td>7.827112</td>
      <td>13.338804</td>
      <td>629826.6484</td>
      <td>61675.32162</td>
      <td>50.625777</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_yreg1=pd.DataFrame(data=data, columns=['Period','EQ'])
data_yreg2=pd.DataFrame(data=test_data, columns=['Period','EQ'])
data_yreg_Final=data_yreg1.append(data_yreg2)
```


```python
data_yreg_Final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Period</th>
      <th>EQ</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016 - Period:1</td>
      <td>504.784933</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2016 - Period:2</td>
      <td>490.226477</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016 - Period:3</td>
      <td>479.244686</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016 - Period:4</td>
      <td>489.057428</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016 - Period:5</td>
      <td>477.031994</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_ARIMAX=pd.concat([data_yreg_Final,data_xreg_Final], axis=1, ignore_index=True)
```


```python
data_ARIMAX= pd.DataFrame(data=data, columns=['Period','EQ','Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price'])
```


```python
data_ARIMAX.shape
```




    (34, 17)




```python
from sklearn.preprocessing import MinMaxScaler
```


```python
scaler=MinMaxScaler()
```


```python
scaler.fit(data[['EQ','Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price']])



d=scaler.transform(data[['EQ','Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price']])
```


```python
d=pd.DataFrame(d,columns=['EQ','Inflation',
'Est_ACV_Selling',
'pct_ACV',
'Fuel_Price',
'Avg_no_of_Items',
'pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI',
'Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct',
'EQ_Subcategory',
'Trade_Invest',
'Avg_EQ_Price'])
```


```python
d[['EQ','Est_ACV_Selling',
'pct_ACV']].plot()
plt.show()
```


![png](output_67_0.png)


#### We can clearly observe how the changes in Est_ACV_Selling and pct_ACV brings about a change in EQ in the same direction with certain time lags


```python
d[['EQ','Fuel_Price',
'Avg_no_of_Items']].plot()
plt.show()
```


![png](output_69_0.png)


#### As fuel price increases over time EQ in the same manner tends to decrease over time.Thereby showing a particular trend in the opposite direction whereas Avg_no_of_Items over time doesn't show any significant trend


```python
d[['EQ','pct_PromoMarketDollars_Category',
'EQ_Base_Price',
'EQ_Category',
'Competitor1_RPI']].plot()
plt.show()
```


![png](output_71_0.png)



```python
d[['EQ','Competitor2_RPI',
'Any_Promo_pct_ACV',
'SOS_pct']].plot()
plt.show()
```


![png](output_72_0.png)



```python
from scipy.misc import factorial
```


    ---------------------------------------------------------------------------

    ImportError                               Traceback (most recent call last)

    <ipython-input-544-54a3cbe344ff> in <module>()
    ----> 1 from scipy.misc import factorial
    

    ImportError: cannot import name 'factorial'



```python
import statsmodels.api as sm
sm.tsa.stattools.adfuller(d['EQ'])
```


    ---------------------------------------------------------------------------

    ImportError                               Traceback (most recent call last)

    <ipython-input-545-ec23bb75c87a> in <module>()
    ----> 1 import statsmodels.api as sm
          2 sm.tsa.stattools.adfuller(d['EQ'])
    

    C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\api.py in <module>()
         14 from . import robust
         15 from .robust.robust_linear_model import RLM
    ---> 16 from .discrete.discrete_model import (Poisson, Logit, Probit,
         17                                       MNLogit, NegativeBinomial,
         18                                       GeneralizedPoisson,
    

    C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\discrete\discrete_model.py in <module>()
         43 
         44 from statsmodels.base.l1_slsqp import fit_l1_slsqp
    ---> 45 from statsmodels.distributions import genpoisson_p
         46 
         47 try:
    

    C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\distributions\__init__.py in <module>()
          1 from .empirical_distribution import ECDF, monotone_fn_inverter, StepFunction
    ----> 2 from .edgeworth import ExpandedNormal
          3 from .discrete import genpoisson_p, zipoisson, zigenpoisson, zinegbin
    

    C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\distributions\edgeworth.py in <module>()
          5 import numpy as np
          6 from numpy.polynomial.hermite_e import HermiteE
    ----> 7 from scipy.misc import factorial
          8 from scipy.stats import rv_continuous
          9 import scipy.special as special
    

    ImportError: cannot import name 'factorial'


### Next Steps : I had thought of performing the Augmented Dicky Fuller Test (null hypothesis: The series is sationary,alternative hypothesis: the series is  not stationary) to check whether the series is stationary or not over time.If not I would have differenced the series and took the corresponding lags of the variables for ehich the series become stationary. I would then use the corresponding lags of the variables as the regressor variables in my ARIMA model and similar checks of stationarity I would do for my forecast variable. With the help of the ACF(Auto Correlation Function)plot I would get MA(Moving Average) order i.e. under which lag correlation between the event at time point 't' and time point 't-1' crosses +1 or -1 for the first time,similarly AR(Auto Regressive) order can be found from the Partial autocorrelation function (PACF) plot where we calculate the corrletaion of the event happening at time point t with respect to time point 't-1' keeping all the time points till 't-2' as constant.After we have run an ARIMAX model finally we will try to see the goodness of fit of the model with a part of the existing data (as in we forecast for the latest few time points of our existing data with respect to the model fit based on time points in the recent past).Then we calculate the MAPE(Mean Absolute Percentage Error) of the model.Generally a good value of MAPE should not be avove 15 percent.
